package NIO;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Primer3 {
    public static char[] procitajNizKaraktera(CharBuffer buffer, int n) throws IOException {
        char[] nizKaraktera = new char[n];

        buffer.get(nizKaraktera, 0, n);

        return nizKaraktera;
    }

    public static void main(String[] args) {
        Path path = Paths.get("src/input.txt");

        try (FileChannel channel = FileChannel.open(path)) {
            int buffCapacity = 100;
            ByteBuffer byteBuffer = ByteBuffer.allocate(buffCapacity);

            channel.read(byteBuffer);
            byteBuffer.rewind();

            CharBuffer charBuffer = StandardCharsets.UTF_8.decode(byteBuffer);

            System.out.println(procitajNizKaraktera(charBuffer, 6));

            charBuffer.mark();

            System.out.println(procitajNizKaraktera(charBuffer, 6));

            charBuffer.position(charBuffer.position() + 2);

            System.out.println(procitajNizKaraktera(charBuffer, 6));

            charBuffer.reset();

            System.out.println(procitajNizKaraktera(charBuffer, 6));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
