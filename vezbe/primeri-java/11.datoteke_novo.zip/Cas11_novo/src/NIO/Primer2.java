package NIO;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Primer2 {
    public static void main(String[] args) {
        Path path = Paths.get("src/input.txt");

        try (FileChannel channel = FileChannel.open(path)) {
            int buffCapacity = 100;
            ByteBuffer byteBuffer = ByteBuffer.allocate(buffCapacity);

            channel.read(byteBuffer);

            System.out.println(byteBuffer);
            byteBuffer.rewind();
            System.out.println(byteBuffer);

            while (byteBuffer.hasRemaining()) {
                byte nextByte = byteBuffer.get();
                System.out.print((char)nextByte);
            }
            System.out.println();

            System.out.println(byteBuffer);
            byteBuffer.rewind();
            System.out.println(byteBuffer);

            byte[] bytes = byteBuffer.array();
            String stringBuffer = new String(bytes);

            System.out.println(stringBuffer);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
