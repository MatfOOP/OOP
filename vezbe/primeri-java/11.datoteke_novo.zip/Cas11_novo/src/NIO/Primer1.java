package NIO;


import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class Primer1 {
    public static void main(String[] args) {
        Path inputPath = Paths.get("src/input.txt");

        try {
            List<String> linije = Files.readAllLines(inputPath, StandardCharsets.UTF_8);

            for (String linija : linije)
                System.out.println(linija);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        Path outputPath = Paths.get("src/output.txt");
        List<String> linije = Arrays.asList("Zdravo svete!", "Kako ste danas?", "Ć");

        try {
            Files.write(outputPath, linije);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
