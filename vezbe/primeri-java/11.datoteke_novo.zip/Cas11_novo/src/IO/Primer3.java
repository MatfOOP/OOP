package IO;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

public class Primer3 {
    public static void main(String[] args) {
        Path path = Paths.get("src/input.txt");

        System.out.println("Relativna putanja: " + path.toString());
        System.out.println("Apsolutna putanja: " + path.toAbsolutePath());
        System.out.println("Naziv datoteke: " + path.getFileName());
        System.out.println("Relativna putnja do roditeljskog direktorijuma: "  + path.getParent());
        System.out.println("Root direktorijum: " + path.getRoot());
        System.out.println();

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            int nextChar;
            while ((nextChar = reader.read()) != -1)
                System.out.print((char)nextChar);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
