package IO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Primer4 {
    public static char[] procitajNizKaraktera(BufferedReader reader, int n) throws IOException {
        char[] nizKaraktera = new char[n];

        int tmp = reader.read(nizKaraktera, 0, n);
        if (tmp == -1)
            throw new IOException("Nije uspelo citanje");
        else
            return nizKaraktera;
    }

    public static void main(String[] args) {
        Path inputPath = Paths.get("src/input.txt");

        try (BufferedReader reader = Files.newBufferedReader(inputPath, StandardCharsets.UTF_8)) {
            System.out.println(procitajNizKaraktera(reader, 6));

            reader.mark(1);

            System.out.println(procitajNizKaraktera(reader, 6));

            reader.skip(2);

            System.out.println(procitajNizKaraktera(reader, 6));

            reader.reset();

            System.out.println(procitajNizKaraktera(reader, 6));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
