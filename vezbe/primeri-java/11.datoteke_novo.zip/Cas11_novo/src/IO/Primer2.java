package IO;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Primer2 {
    public static void main(String[] args) {
        try (FileInputStream inputStream = new FileInputStream("src/input.txt")) {
            byte[] nizBajtova = new byte[100];

            int tmp = inputStream.read(nizBajtova, 0, 100);

            for (byte nextByte : nizBajtova)
                System.out.print((char)nextByte);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        try (FileOutputStream outputStream = new FileOutputStream("src/output.txt")) {
            String linije = "Zdravo svete!\nKako ste danas?\nĆ";

            byte[] nizBajtova = linije.getBytes(StandardCharsets.UTF_8);

            outputStream.write(nizBajtova);
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }
}
