package IO;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Primer1 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(new File("src/input.txt"))) {
            while (sc.hasNext())
                System.out.println(sc.next());
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        try (PrintWriter writer = new PrintWriter(new File("src/output.txt"))) {
            writer.println("Zdravo svete!");
            writer.println("Kako ste danas?");
            writer.println("Ć");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
