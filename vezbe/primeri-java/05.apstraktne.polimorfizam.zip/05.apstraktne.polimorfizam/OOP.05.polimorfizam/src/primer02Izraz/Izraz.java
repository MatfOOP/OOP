package primer02Izraz;

public abstract class Izraz {
	public abstract double izracunaj();
}
