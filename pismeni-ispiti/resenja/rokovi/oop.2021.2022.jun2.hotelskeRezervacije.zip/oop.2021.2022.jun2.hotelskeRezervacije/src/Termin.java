public class Termin implements Comparable<Termin>{
    private Datum datumOd;
    private Datum datumDo;

    public Termin(Datum datumOd, Datum datumDo) {
        if(datumOd.compareTo(datumDo) >= 0)
            throw new IllegalArgumentException("Nevalidan termin!");
        this.datumOd = datumOd;
        this.datumDo = datumDo;
    }

    @Override
    public String toString() {
        return datumOd + " - " + datumDo;
    }

    public boolean preklapaSeSa(Termin t){
        if(this.datumOd.compareTo(t.datumOd) < 0)
            return this.datumDo.compareTo(t.datumOd) > 0;
        else if(this.datumOd.compareTo(t.datumOd) > 0)
            return t.datumDo.compareTo(this.datumOd) > 0;
        else
            return true;
    }

    @Override
    public int compareTo(Termin t) {
        return datumOd.compareTo(t.datumOd);
    }
}
