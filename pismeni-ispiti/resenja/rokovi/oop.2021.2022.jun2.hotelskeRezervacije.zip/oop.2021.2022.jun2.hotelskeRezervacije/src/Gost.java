public class Gost {
    private String imePrezime;
    private int budzet;
    private boolean premium;

    public Gost(String imePrezime, int budzet, boolean premium) {
        this.imePrezime = imePrezime;
        this.budzet = budzet;
        this.premium = premium;
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public int getBudzet() {
        return budzet;
    }

    public boolean isPremium() {
        return premium;
    }


    @Override
    public String toString() {
        return imePrezime + (premium ? "*" : "") + ", " + budzet;
    }
}
