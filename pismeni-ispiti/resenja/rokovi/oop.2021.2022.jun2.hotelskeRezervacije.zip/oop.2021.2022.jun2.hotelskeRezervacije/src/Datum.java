public class Datum implements Comparable<Datum>{
    private int dan;
    private int mesec;

    public Datum(int dan, int mesec) {
        this.dan = dan;
        this.mesec = mesec;
    }

    public Datum(String datum){
        String[] elem = datum.split("/");
        this.dan = Integer.parseInt(elem[0]);
        this.mesec = Integer.parseInt(elem[1]);
    }

    @Override
    public String toString() {
        return dan + "/" + mesec;
    }

    @Override
    public int compareTo(Datum d) {
        if(this.mesec != d.mesec)
            return Integer.compare(this.mesec, d.mesec);
        else
            return Integer.compare(this.dan, d.dan);
    }
}
