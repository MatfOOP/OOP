import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Hotel extends Application {
    private List<Soba> sobe = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxGornji = new HBox(10);
        HBox hBoxDonji = new HBox(10);
        hBoxDonji.setAlignment(Pos.CENTER_RIGHT);

        vBoxRoot.getChildren().addAll(hBoxGornji, hBoxDonji);

        //---------------------------------------------------------------------------

        VBox vBoxUnosPodataka = new VBox(10);
        TextArea textArea = new TextArea("");
        textArea.setPrefHeight(500);
        textArea.setPrefWidth(300);

        hBoxGornji.getChildren().addAll(vBoxUnosPodataka, textArea);

        //---------------------------------------------------------------------------

        Button buttonUcitajSobe = new Button("Ucitaj sobe");
        Button buttonPronadjiSobu = new Button("Pronadji sobu");
        Button buttonPregledZauzeca = new Button("Pregled zauzeca");

        hBoxDonji.getChildren().addAll(buttonUcitajSobe, buttonPronadjiSobu, buttonPregledZauzeca);

        //---------------------------------------------------------------------------

        Label labelImePrezime = new Label("Ime i prezime:");
        TextField textFieldImePrezime = new TextField("");
        Label labelStrukturaSobe = new Label("Struktura sobe:");
        TextField textFieldStrukturaSobe = new TextField("");
        Label labelBudzet = new Label("Budzet:");
        TextField textFieldBudzet = new TextField("");
        Label labelDatumOd = new Label("Datum od:");
        TextField textFieldDatumOd = new TextField("");
        Label labelDatumDo = new Label("Datum do:");
        TextField textFieldDatumDo = new TextField("");
        CheckBox checkBoxPremium = new CheckBox("Premium korisnik");

        vBoxUnosPodataka.getChildren().addAll(labelImePrezime, textFieldImePrezime, labelStrukturaSobe, textFieldStrukturaSobe, labelBudzet, textFieldBudzet, labelDatumOd, textFieldDatumOd, labelDatumDo, textFieldDatumDo, checkBoxPremium);

        //---------------------------------------------------------------------------

        buttonUcitajSobe.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                buttonUcitajSobe.setDisable(true);
                try {
                    List<String> linije = Files.readAllLines(Paths.get("src/sobe.txt"));

                    for(String linija : linije) {
                        String[] elem = linija.split(", ");
                        int brojSobe = Integer.parseInt(elem[0].trim());
                        int strukturaSobe = Integer.parseInt(elem[1].trim());
                        int cena = Integer.parseInt(elem[2].trim());
                        if(elem.length == 3)
                            sobe.add(new StandardnaSoba(brojSobe, strukturaSobe, cena));
                        else
                            sobe.add(new PremiumSoba(brojSobe, strukturaSobe, cena));
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        buttonPronadjiSobu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    String imePrezime = textFieldImePrezime.getText();
                    int strukturaSobe = Integer.parseInt(textFieldStrukturaSobe.getText());
                    int budzet = Integer.parseInt(textFieldBudzet.getText());
                    Datum odDatum = new Datum(textFieldDatumOd.getText());
                    Datum doDatum = new Datum(textFieldDatumDo.getText());

                    Gost gost = new Gost(imePrezime, budzet, checkBoxPremium.isSelected());
                    Termin termin = new Termin(odDatum, doDatum);

                    for (Soba s : sobe) {
                        if(s.getStrukturaSobe() >= strukturaSobe && s.smesti(termin, gost)){
                            textArea.setText("Gost: " + gost + "\nsmesten je u sobi " + s.getBrojSobe() + "\nu terminu: " + termin);
                            return;
                        }
                    }
                    textArea.setText("Nije pronadjena odgovarajuća soba");
                }
                catch (IllegalArgumentException e) {
                    textArea.setText("Neispravno uneti podaci!");
                }
            }
        });



        buttonPregledZauzeca.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textArea.setText("");

                for (Soba s : sobe) {
                    textArea.appendText(s.toString());
                    textArea.appendText("------------------------------------\n");
                }
            }
        });

        //---------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 500, 450);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Hotelske rezervacije");
        primaryStage.show();
    }
}
