import java.util.Map;
import java.util.TreeMap;

public abstract class Soba {
    private int brojSobe;
    private int strukturaSobe;
    private int cena;
    private Map<Termin, Gost> zauzece;

    public Soba(int brojSobe, int strukturaSobe, int cena) {
        this.brojSobe = brojSobe;
        this.strukturaSobe = strukturaSobe;
        this.cena = cena;
        this.zauzece = new TreeMap<>();
    }

    public int getBrojSobe() {
        return brojSobe;
    }

    public int getStrukturaSobe() {
        return strukturaSobe;
    }

    public int getCena() {
        return cena;
    }

    public Map<Termin, Gost> getZauzece() {
        return zauzece;
    }

    public abstract boolean smesti(Termin termin, Gost gost);

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(brojSobe).append(", ").append(strukturaSobe).append(", ").append(cena).append("dinara").append("\n");

        for (Map.Entry<Termin, Gost> entry : zauzece.entrySet())
            sb.append("-> ").append(entry.getKey()).append(", ").append(entry.getValue()).append("\n");

        return sb.toString();
    }
}
