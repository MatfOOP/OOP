import java.util.Map;

public class StandardnaSoba extends Soba {
    public StandardnaSoba(int brojSobe, int strukturaSobe, int cena) {
        super(brojSobe, strukturaSobe, cena);
    }

    @Override
    public boolean smesti(Termin termin, Gost gost) {
        boolean zauzeto = false;
        for (Termin t : this.getZauzece().keySet()){
            if (t.preklapaSeSa(termin))
                zauzeto = true;
        }
        if(!zauzeto && this.getCena() <= gost.getBudzet()){
            getZauzece().put(termin, gost);
            return true;
        }
        else
            return false;
    }

    @Override
    public String toString() {
        return "Standardna soba " + super.toString();
    }
}
