public class PremiumSoba extends Soba {
    public PremiumSoba(int brojSobe, int strukturaSobe, int cena) {
        super(brojSobe, strukturaSobe, cena);
    }

    @Override
    public boolean smesti(Termin termin, Gost gost) {
        boolean zauzeto = false;
        for (Termin t : this.getZauzece().keySet()){
            if (t.preklapaSeSa(termin))
                zauzeto = true;
        }

        int cenaSobe = this.getCena();
        if(gost.isPremium())
            cenaSobe *= 0.85;

        if(!zauzeto && cenaSobe <= gost.getBudzet()){
            getZauzece().put(termin, gost);
            return true;
        }
        else
            return false;
    }

    @Override
    public String toString() {
        return "Premium soba " + super.toString();
    }
}
