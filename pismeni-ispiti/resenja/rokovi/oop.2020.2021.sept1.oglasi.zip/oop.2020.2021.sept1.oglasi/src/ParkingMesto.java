public class ParkingMesto extends Nekretnina{
    private boolean natkrivenost;

    public ParkingMesto(String opstina, double kmOdCentra, double kvadratura, int cena, boolean natkrivenost) {
        super(opstina, kmOdCentra, kvadratura, cena);
        this.natkrivenost = natkrivenost;
    }

    public boolean getNatkrivenost() {
        return natkrivenost;
    }

    @Override
    public String toString() {
        return super.toString() + ", natkrivenost: " + ((natkrivenost) ? "DA" : "NE");
    }

    @Override
    public double isplativostNekretnine() {
        return this.getCena() / this.getKmOdCentra() + ((natkrivenost) ? 1 : 0);
    }
}
