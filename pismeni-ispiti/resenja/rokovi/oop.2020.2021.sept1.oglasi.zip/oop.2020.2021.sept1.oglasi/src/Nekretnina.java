public abstract class Nekretnina {
    private String opstina;
    private double kmOdCentra;
    private double kvadratura;
    private int cena;

    public Nekretnina(String opstina, double kmOdCentra, double kvadratura, int cena){
        this.opstina = opstina;
        this.kmOdCentra = kmOdCentra;
        this.kvadratura = kvadratura;
        this.cena = cena;
    }

    public String getOpstina() {
        return opstina;
    }

    public double getKmOdCentra() {
        return kmOdCentra;
    }

    public double getKvadratura() {
        return kvadratura;
    }

    public int getCena() {
        return cena;
    }

    @Override
    public String toString() {
        return opstina + ", "  + kmOdCentra + " km od centra, " + kvadratura + " m^2, " + cena + " evra";
    }

    public abstract double isplativostNekretnine();
}
