public class Kuca extends Nekretnina{
    private double povrsinaPoseda;

    public Kuca(String opstina, double kmOdCentra, double kvadratura, int cena, double povrsinaPoseda) {
        super(opstina, kmOdCentra, kvadratura, cena);
        this.povrsinaPoseda = povrsinaPoseda;
    }

    public double getPovrsinaPoseda() {
        return povrsinaPoseda;
    }

    @Override
    public String toString() {
        return super.toString() + ", povrsina poseda: " + povrsinaPoseda + " ar";
    }

    @Override
    public double isplativostNekretnine() {
        return this.getCena() / (this.getKvadratura() + povrsinaPoseda * 100 * 0.7);
    }
}
