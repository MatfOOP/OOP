public class Stan extends Nekretnina {
    private boolean parkingMesto;

    public Stan(String opstina, double kmOdCentra, double kvadratura, int cena, boolean parkingMesto) {
        super(opstina, kmOdCentra, kvadratura, cena);
        this.parkingMesto = parkingMesto;
    }

    public boolean getParkingMesto() {
        return parkingMesto;
    }

    @Override
    public String toString() {
        return super.toString() + ", parking mesto: " + ((parkingMesto) ? "IMA" : "NEMA");
    }

    @Override
    public double isplativostNekretnine() {
        return this.getCena() / (this.getKvadratura() + ((parkingMesto) ? 1 : 0) * 10 * 0.8);
    }
}
