import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PretragaOglasa extends Application {
    private List<Nekretnina> oglasi = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxIzbori = new HBox(10);
        TextArea textArea = new TextArea();
        Button buttonPretrazi = new Button("Pretrazi oglase");

        vBoxRoot.setAlignment(Pos.TOP_RIGHT);
        vBoxRoot.getChildren().addAll(hBoxIzbori, textArea, buttonPretrazi);

        //---------------------------------------------------------------------------

        VBox vBoxTipNekretnine = new VBox(10);
        VBox vBoxFiltriranje = new VBox(10);
        VBox vBoxSortiranje = new VBox(10);

        hBoxIzbori.getChildren().addAll(vBoxTipNekretnine, vBoxFiltriranje, vBoxSortiranje);

        //--------------------------------------------------------------------------

        Label labelStaTrazite = new Label("Tip nekretnine:");
        RadioButton radioButtonStan = new RadioButton("Stan");
        RadioButton radioButtonKuca = new RadioButton("Kuca");
        RadioButton radioButtonParkingMesto = new RadioButton("Parking mesto");

        ToggleGroup toggleGroupTipNekretnine = new ToggleGroup();
        radioButtonStan.setToggleGroup(toggleGroupTipNekretnine);
        radioButtonKuca.setToggleGroup(toggleGroupTipNekretnine);
        radioButtonParkingMesto.setToggleGroup(toggleGroupTipNekretnine);
        radioButtonStan.setSelected(true);

        vBoxTipNekretnine.getChildren().addAll(labelStaTrazite, radioButtonStan, radioButtonKuca, radioButtonParkingMesto);

        //----------------------------------------------------------------------------

        TextField textFieldLokacija = new TextField();
        textFieldLokacija.setPromptText("Upisite lokaciju (opštinu)...");
        HBox hBoxFiltriranje = new HBox(10);

        vBoxFiltriranje.getChildren().addAll(textFieldLokacija, hBoxFiltriranje);

        //---------------------------------------------------------------------------

        VBox vBoxFiltriranjeCena = new VBox(10);
        VBox vBoxFiltriranjeKvadratura = new VBox(10);

        hBoxFiltriranje.getChildren().addAll(vBoxFiltriranjeCena, vBoxFiltriranjeKvadratura);

        //---------------------------------------------------------------------------

        Label labelCenaDo = new Label("Cena do:");
        TextField textFieldCenaDo = new TextField();
        textFieldCenaDo.setPromptText("U evrima");

        vBoxFiltriranjeCena.getChildren().addAll(labelCenaDo, textFieldCenaDo);

        //---------------------------------------------------------------------------

        Label labelKvadraturaOd = new Label("Kvadratura od:");
        TextField textFieldKvadraturaOd = new TextField();
        textFieldKvadraturaOd.setPromptText("U metrima kvadratnim");

        vBoxFiltriranjeKvadratura.getChildren().addAll(labelKvadraturaOd, textFieldKvadraturaOd);

        //---------------------------------------------------------------------------

        Label labelSortiranje = new Label("Sortiranje:");
        RadioButton radioButtonCenaRastuce = new RadioButton("Cena (rastuce)");
        RadioButton radioButtonUdaljenostOdCentra = new RadioButton("Udaljenost od centra");
        RadioButton radioButtonIsplativostNekretnine = new RadioButton("Isplativost nekretnine");

        ToggleGroup toggleGroupKriterijumSortiranja = new ToggleGroup();
        radioButtonCenaRastuce.setToggleGroup(toggleGroupKriterijumSortiranja);
        radioButtonUdaljenostOdCentra.setToggleGroup(toggleGroupKriterijumSortiranja);
        radioButtonIsplativostNekretnine.setToggleGroup(toggleGroupKriterijumSortiranja);
        radioButtonCenaRastuce.setSelected(true);

        vBoxSortiranje.getChildren().addAll(labelSortiranje, radioButtonCenaRastuce, radioButtonUdaljenostOdCentra, radioButtonIsplativostNekretnine);

        //---------------------------------------------------------------------------

        buttonPretrazi.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                List<Nekretnina> trazeniOglasi = new ArrayList<>();

                Class tipNekretnine;
                if(radioButtonStan.isSelected())
                    tipNekretnine = Stan.class;
                else if(radioButtonKuca.isSelected())
                    tipNekretnine = Kuca.class;
                else
                    tipNekretnine = ParkingMesto.class;

                for (Nekretnina n : oglasi)
                    if (n.getClass() == tipNekretnine)
                        trazeniOglasi.add(n);

                String lokacija = textFieldLokacija.getText();
                String strCenaDo = textFieldCenaDo.getText();
                String strKvadraturaOd = textFieldKvadraturaOd.getText();

                if(!lokacija.isEmpty()){
                    for (int i = 0; i < trazeniOglasi.size(); i++) {
                        if(trazeniOglasi.get(i).getOpstina().compareTo(lokacija) != 0){
                            trazeniOglasi.remove(i);
                            i--;
                        }
                    }
                }

                if(!strCenaDo.isEmpty()){
                    int cenaDo = Integer.parseInt(textFieldCenaDo.getText());
                    for (int i = 0; i < trazeniOglasi.size(); i++) {
                        if(trazeniOglasi.get(i).getCena() > cenaDo){
                            trazeniOglasi.remove(i);
                            i--;
                        }
                    }
                }

                if(!strKvadraturaOd.isEmpty()){
                    double kvadraturaOd = Double.parseDouble(textFieldKvadraturaOd.getText());
                    for (int i = 0; i < trazeniOglasi.size(); i++) {
                        if(trazeniOglasi.get(i).getKvadratura() < kvadraturaOd){
                            trazeniOglasi.remove(i);
                            i--;
                        }
                    }
                }

                if(radioButtonCenaRastuce.isSelected())
                    Collections.sort(trazeniOglasi, new Comparator<Nekretnina>() {
                        @Override
                        public int compare(Nekretnina n1, Nekretnina n2) {
                            return Integer.compare(n1.getCena(), n2.getCena());
                        }
                    });

                else if(radioButtonUdaljenostOdCentra.isSelected())
                    Collections.sort(trazeniOglasi, new Comparator<Nekretnina>() {
                        @Override
                        public int compare(Nekretnina n1, Nekretnina n2) {
                            return Double.compare(n1.getKmOdCentra(), n2.getKmOdCentra());
                        }
                    });
                else if(radioButtonIsplativostNekretnine.isSelected())
                    Collections.sort(trazeniOglasi, new Comparator<Nekretnina>() {
                        @Override
                        public int compare(Nekretnina n1, Nekretnina n2) {
                            return -Double.compare(n1.isplativostNekretnine(), n2.isplativostNekretnine());
                        }
                    });

                textArea.clear();
                for (Nekretnina n : trazeniOglasi)
                    textArea.appendText(n.toString() + "\n");

                if(trazeniOglasi.isEmpty())
                    textArea.setText("Nema oglasa koji zadovoljavaju trazene kriterijume.");
            }
        });

        //----------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 680, 350);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Oglasi");
        primaryStage.show();

        ucitaj();
    }

    private void ucitaj(){
        try (Scanner sc = new Scanner(new File("src/oglasi.txt"))) {
            while(sc.hasNextLine()) {
                String linija = sc.nextLine();
                String[] strs = linija.split(" ");
                switch (strs[0]) {
                    case "STAN":
                        oglasi.add(new Stan(strs[1], Double.parseDouble(strs[2]), Double.parseDouble(strs[3]), Integer.parseInt(strs[4]), strs[5].compareTo("DA") == 0 ? true : false));
                        break;
                    case "KUCA":
                        oglasi.add(new Kuca(strs[1], Double.parseDouble(strs[2]), Double.parseDouble(strs[3]), Integer.parseInt(strs[4]), Double.parseDouble(strs[5])));
                        break;
                    case "PARKING_MESTO":
                        oglasi.add(new ParkingMesto(strs[1], Double.parseDouble(strs[2]), Double.parseDouble(strs[3]), Integer.parseInt(strs[4]), strs[5].compareTo("DA") == 0 ? true : false));
                        break;
                    default:
                        throw new IOException("Datoteka nije u ispravnom formatu!");
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        for (Nekretnina n : oglasi)
            System.out.println(n);
    }
}
