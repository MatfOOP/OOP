public class MenhetnMetrika implements Metrika {
    @Override
    public double rastojanje(Vektor u, Vektor v) {
        if (u.velicina() != v.velicina())
            throw new IllegalArgumentException("Vektori su razlicitih velicina!");

        double sumaAbsVredRazlika = 0;
        for (int i = 0; i < u.velicina(); i++)
            sumaAbsVredRazlika += Math.abs(u.uzmiElement(i) - v.uzmiElement(i));
        return sumaAbsVredRazlika;
    }
}
