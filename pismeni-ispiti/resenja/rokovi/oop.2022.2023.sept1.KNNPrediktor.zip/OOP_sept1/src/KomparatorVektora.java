import java.util.Comparator;

public class KomparatorVektora implements Comparator<Vektor> {
    private Vektor targetVektor;
    private Metrika metrika;

    public KomparatorVektora(Vektor targetVektor, Metrika metrika){
        this.targetVektor = targetVektor;
        this.metrika = metrika;
    }

    @Override
    public int compare(Vektor u, Vektor v) {
        Vektor podvektorU = u.podvektor(0, u.velicina()-2);
        Vektor podvektorV = v.podvektor(0, v.velicina()-2);

        double rastojanjeU = metrika.rastojanje(podvektorU, targetVektor);
        double rastojanjeV = metrika.rastojanje(podvektorV, targetVektor);

        return Double.compare(rastojanjeU, rastojanjeV);
    }
}
