public interface Metrika {
    double rastojanje(Vektor u, Vektor v);
}
