import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class VektorskiProstor {
    private ArrayList<String> naziviKoordinata;
    private ArrayList<Vektor> vektori;

    public VektorskiProstor(){
        naziviKoordinata = new ArrayList<>();
        vektori = new ArrayList<>();
    }

    public ArrayList<Vektor> getVektori() {
        return vektori;
    }

    public void ucitajIzFajla(String filePath){
        try {
            List<String> linije = Files.readAllLines(Paths.get(filePath));

            String prvaLinija = linije.get(0);
            for (String nazivKoord : prvaLinija.split(" "))
                naziviKoordinata.add(nazivKoord);

            for (int i = 1; i < linije.size(); i++){
                String linija = linije.get(i);
                Vektor v = new Vektor();
                for (String e : linija.split(" ")){
                    v.dodajElement(Double.parseDouble(e));
                }
                vektori.add(v);
            }
        }
        catch (IOException e){
            System.err.println("Nije uspelo ucitavanje iz fajla " + filePath);
            System.exit(1);
        }
        catch (NumberFormatException e){
            System.err.println("Nedozvoljen format zadavanja koordinata vektora u fajlu");
            System.exit(1);
        }
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();

        sb.append(naziviKoordinata.toString()).append("\n");

        for (Vektor v : vektori)
            sb.append(v).append("\n");

        return sb.toString();
    }
}
