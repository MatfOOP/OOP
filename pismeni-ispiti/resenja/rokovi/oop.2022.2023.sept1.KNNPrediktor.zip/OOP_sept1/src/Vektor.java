import java.util.ArrayList;

public class Vektor {
    private ArrayList<Double> elementi;
    private int n;

    public Vektor(ArrayList<Double> elementi) {
        this.elementi = elementi;
        this.n = elementi.size();
    }

    public Vektor(){
        this.elementi = new ArrayList<>();
        this.n = 0;
    }

    public int velicina(){
        return n;
    }

    public void dodajElement(Double e){
        elementi.add(e);
        n += 1;
    }

    public Double uzmiElement(int ind) {
        if (ind > elementi.size())
            throw new IndexOutOfBoundsException("Indeks trazenog elementa vektora je van opsega");
        return elementi.get(ind);
    }

    public Vektor podvektor(int i, int j){
        if (i < 0 || j > this.velicina()-1)
            throw new IllegalArgumentException("Opseg podvektora je van dozvoljenih granica");

        Vektor v = new Vektor();
        for (int k = i; k <= j; k++)
            v.dodajElement(this.uzmiElement(k));
        return v;
    }

    @Override
    public String toString() {
        return elementi.toString();
    }
}
