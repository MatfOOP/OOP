import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Arrays;

public class CenaNekretninaKNN extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxTop = new HBox(10);
        HBox hBoxBottom = new HBox(10);

        vBoxRoot.getChildren().addAll(hBoxTop, hBoxBottom);

        //----------------------------------------------------------------------------------

        VBox vBoxSpecifikacijeNekretnine = new VBox(10);
        VBox vBoxIzborKNNParametara = new VBox(10);
        vBoxIzborKNNParametara.setPadding(new Insets(0, 0, 0,30 ));

        hBoxTop.getChildren().addAll(vBoxSpecifikacijeNekretnine, vBoxIzborKNNParametara);

        //----------------------------------------------------------------------------------

        Label labelGreska = new Label();
        labelGreska.setTextFill(Color.RED);
        labelGreska.setMinSize(350, 25);
        Button buttonUcitaj = new Button("Ucitaj bazu podataka");

        hBoxBottom.getChildren().addAll(labelGreska, buttonUcitaj);

        //----------------------------------------------------------------------------------

        HBox hBoxKvadratura = new HBox(10);
        HBox hBoxStruktura = new HBox(10);
        HBox hBoxSpratnost = new HBox(10);
        HBox hBoxUdaljenost = new HBox(10);
        HBox hBoxCena = new HBox(10);

        vBoxSpecifikacijeNekretnine.getChildren().addAll(hBoxKvadratura, hBoxStruktura, hBoxSpratnost, hBoxUdaljenost, hBoxCena);

        //----------------------------------------------------------------------------------

        Label labelIzborMetrike = new Label("Izbor metrike:");
        RadioButton radioButtonEuklidska = new RadioButton("Euklidska metrika");
        RadioButton radioButtonMenhetn = new RadioButton("Menhetn metrika");
        ToggleGroup toggleGroup = new ToggleGroup();
        radioButtonEuklidska.setToggleGroup(toggleGroup);
        radioButtonMenhetn.setToggleGroup(toggleGroup);
        radioButtonEuklidska.setSelected(true);

        Label labelK = new Label("Vrednost parametra k:");
        TextField textFieldK = new TextField();

        vBoxIzborKNNParametara.getChildren().addAll(labelIzborMetrike, radioButtonEuklidska, radioButtonMenhetn, labelK, textFieldK);

        //----------------------------------------------------------------------------------

        Label labelKvadratura = new Label("Kvadratura:");
        labelKvadratura.setMinSize(150, 25);
        TextField textFieldKvadratura = new TextField();

        hBoxKvadratura.getChildren().addAll(labelKvadratura, textFieldKvadratura);

        //----------------------------------------------------------------------------------

        Label labelStruktura = new Label("Struktura:");
        labelStruktura.setMinSize(150, 25);
        TextField textFieldStruktura = new TextField();

        hBoxStruktura.getChildren().addAll(labelStruktura, textFieldStruktura);

        //----------------------------------------------------------------------------------

        Label labelSpratnost = new Label("Spratnost:");
        labelSpratnost.setMinSize(150, 25);
        TextField textFieldSpratnost = new TextField();

        hBoxSpratnost.getChildren().addAll(labelSpratnost, textFieldSpratnost);

        //----------------------------------------------------------------------------------

        Label labelUdaljenost = new Label("Udaljenost od centra:");
        labelUdaljenost.setMinSize(150, 25);
        TextField textFieldUdaljenost = new TextField();

        hBoxUdaljenost.getChildren().addAll(labelUdaljenost, textFieldUdaljenost);

        //-----------------------------------------------------------------------------------

        Button buttonPredvidiCenu = new Button("Predvidi cenu");
        buttonPredvidiCenu.setMinWidth(150);
        Label labelCena = new Label();
        labelCena.setTextFill(Color.BLUE);
        labelCena.setMinSize(150, 25);

        hBoxCena.getChildren().addAll(buttonPredvidiCenu, labelCena);

        //-----------------------------------------------------------------------------------

        VektorskiProstor vp = new VektorskiProstor();

        buttonUcitaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                buttonUcitaj.setDisable(true);
                vp.ucitajIzFajla("src/nekretnine.txt");
                System.out.println(vp);
            }
        });

        buttonPredvidiCenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try{
                    double kvadratura = Double.parseDouble(textFieldKvadratura.getText().trim());
                    double struktura = Double.parseDouble(textFieldStruktura.getText().trim());
                    double spratnost = Double.parseDouble(textFieldSpratnost.getText().trim());
                    double udaljenost = Double.parseDouble(textFieldUdaljenost.getText().trim());
                    Vektor targetVektor = new Vektor(new ArrayList<>(Arrays.asList(kvadratura, struktura, spratnost, udaljenost)));

                    int k = Integer.parseInt(textFieldK.getText().trim());

                    Metrika metrika;
                    if (radioButtonEuklidska.isSelected())
                        metrika = new EuklidskaMetrika();
                    else
                        metrika = new MenhetnMetrika();

                    KNNPrediktor prediktor = new KNNPrediktor(vp, metrika, k);

                    double cena = prediktor.predvidjanjeCiljnePromen(targetVektor);
                    labelCena.setText(String.format("%.2f",cena));
                }
                catch (NumberFormatException e){
                    labelGreska.setText("Nedozvoljen format brojcanih unosa");
                }
            }
        });


        //-----------------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 550, 230);
        primaryStage.setScene(scene);
        primaryStage.setTitle("KNN prediktor cena nekretnina");
        primaryStage.show();
    }
}
