import java.util.ArrayList;
import java.util.Collections;

public class KNNPrediktor {
    private VektorskiProstor vp;
    private Metrika metrika;
    private int k;

    public KNNPrediktor(VektorskiProstor vp, Metrika metrika, int k) {
        this.vp = vp;
        this.metrika = metrika;
        this.k = k;
    }

    public double predvidjanjeCiljnePromen(Vektor targetVektor){
        ArrayList<Vektor> vektoriZaSort = new ArrayList<>(vp.getVektori());

        KomparatorVektora komparator = new KomparatorVektora(targetVektor, metrika);
        Collections.sort(vektoriZaSort, komparator);

        double targetCena = 0;
        for (int i = 0; i < k; i++){
            Vektor v = vektoriZaSort.get(i);
            targetCena += v.uzmiElement(v.velicina()-1);
        }

        return targetCena / k;
    }
}
