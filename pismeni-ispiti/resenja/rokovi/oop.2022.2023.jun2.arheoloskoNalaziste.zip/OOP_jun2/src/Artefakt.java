public abstract class Artefakt {
    private String oznaka;
    private String materijal;
    private PraistorijskoDoba doba;

    private static int brojacInstanciKlase = 0;

    public Artefakt(String oznaka, String materijal, PraistorijskoDoba doba) {
        brojacInstanciKlase += 1;
        this.oznaka = brojacInstanciKlase + oznaka;
        this.materijal = materijal;
        this.doba = doba;
    }

    public abstract boolean iskopajArtefakt(int kvalifikacijaArheologa);

    @Override
    public String toString() {
        return oznaka + " | " + materijal + " | " + doba;
    }
}
