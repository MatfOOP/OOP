import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class Main extends Application {
    private ArheoloskoNalaziste nalaziste;
    private Arheolog trenutniArheolog;
    private Map<Arheolog, List<Artefakt>> zbirkaIskopina = new TreeMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxTop = new HBox(10);
        Label labelPoruka = new Label();
        TextArea textArea = new TextArea();
        HBox hBoxBottom = new HBox(10);

        vBoxRoot.getChildren().addAll(hBoxTop, labelPoruka, textArea, hBoxBottom);

        //----------------------------------------------------------------------------

        VBox vBoxImePrezime = new VBox(10);
        VBox vBoxKvalifikacija = new VBox(10);
        Button buttonAngazujArheologa = new Button("Angazuj arheologa");

        hBoxTop.setAlignment(Pos.BOTTOM_LEFT);
        hBoxTop.getChildren().addAll(vBoxImePrezime, vBoxKvalifikacija, buttonAngazujArheologa);

        //----------------------------------------------------------------------------

        Label labelImePrezime = new Label("Ime i prezime:");
        TextField textFieldImePrezime = new TextField();

        vBoxImePrezime.getChildren().addAll(labelImePrezime, textFieldImePrezime);

        //----------------------------------------------------------------------------

        Label labelKvalifikacija = new Label("Kvalifikacija (1-10):");
        TextField textFieldKvalifikacija = new TextField();

        vBoxKvalifikacija.getChildren().addAll(labelKvalifikacija, textFieldKvalifikacija);

        //----------------------------------------------------------------------------

        Button buttonOtkrijNalaziste = new Button("Otkrij nalaziste");
        Button buttonIskopajArtefakt = new Button("Iskopaj artefakt");
        Button buttonIspisiZbirkuIskopina = new Button("Ispisi zbirku iskopina");;

        hBoxBottom.getChildren().addAll(buttonOtkrijNalaziste, buttonIskopajArtefakt, buttonIspisiZbirkuIskopina);

        //----------------------------------------------------------------------------

        buttonOtkrijNalaziste.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                List<Artefakt> artefakti = new ArrayList<>();

                try {
                    List<String> linije = Files.readAllLines(Paths.get("src/nalaziste.txt"));

                    for (String linija : linije){
                        String[] elems = linija.split(",");

                        switch (elems[0].charAt(0)){
                            case 'O' : artefakti.add(new Orudje(elems[0].trim(), elems[2].trim(), PraistorijskoDoba.odOznake(elems[1].trim()))); break;
                            case 'P' : artefakti.add(new Posuda(elems[0].trim(), elems[2].trim(), PraistorijskoDoba.odOznake(elems[1].trim()))); break;
                            case 'F' : artefakti.add(new Figurina(elems[0].trim(), elems[2].trim(), PraistorijskoDoba.odOznake(elems[1].trim()))); break;
                            default : throw new IOException("Fajl nije dobrog formata");
                        }
                    }

                    nalaziste = new ArheoloskoNalaziste(artefakti);
                    buttonOtkrijNalaziste.setDisable(true);
                }
                catch (IOException e){
                    e.printStackTrace();
                }
            }
        });

        buttonAngazujArheologa.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String imePrezime = textFieldImePrezime.getText().trim();

                trenutniArheolog = null;

                for (Arheolog arheolog : zbirkaIskopina.keySet()) {
                    if (arheolog.getImePrezime().compareTo(imePrezime) == 0) {
                        if (arheolog.isLicenciran()) {
                            trenutniArheolog = arheolog;
                            labelPoruka.setTextFill(Color.BLUE);
                            labelPoruka.setText("Postojeci arheolog " + imePrezime + " je licenciran za iskopavanja");
                            return;
                        } else {
                            labelPoruka.setTextFill(Color.RED);
                            labelPoruka.setText("Postojeci arheolog " + imePrezime + " nije licenciran za iskopavanja");
                            return;
                        }
                    }
                }

                if (trenutniArheolog == null) {
                    if (textFieldKvalifikacija.getText().trim().isEmpty()) {
                        labelPoruka.setText("Potrebno je uneti kvalifikaciju za novog arheologa");
                        return;
                    }

                    int kvalifikacija = Integer.parseInt(textFieldKvalifikacija.getText().trim());
                    trenutniArheolog = new Arheolog(imePrezime, kvalifikacija);
                    zbirkaIskopina.put(trenutniArheolog, new ArrayList<>());

                    labelPoruka.setTextFill(Color.GREEN);
                    labelPoruka.setText("Angazovan je novi arheolog " + imePrezime + " koji je licenciran za iskopavanja");
                }
            }
        });

        buttonIskopajArtefakt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Artefakt iskopanArtefakt = nalaziste.iskopavanje(trenutniArheolog);

                if (iskopanArtefakt == null)
                    textArea.appendText("Neuspesno iskopavanje. Artefakt je unisten prilikom iskopavanja.\n");
                else{
                    textArea.appendText("Iskopan artefakt : " + iskopanArtefakt + "\n");
                    zbirkaIskopina.get(trenutniArheolog).add(iskopanArtefakt);
                }
            }
        });

        buttonIspisiZbirkuIskopina.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                labelPoruka.setText("");
                textArea.clear();

                for (Map.Entry<Arheolog, List<Artefakt>> entry : zbirkaIskopina.entrySet()){
                    Arheolog arheolog = entry.getKey();
                    List<Artefakt> iskopaniArtefakti = entry.getValue();

                    textArea.appendText(arheolog + ": \n");
                    for (Artefakt artefakt : iskopaniArtefakti)
                        textArea.appendText(artefakt + "\n");
                    textArea.appendText("\n");
                }
            }
        });

        //----------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 550, 300);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Arheolosko nalaziste");
        primaryStage.show();
    }
}
