import java.util.Random;

public class Posuda extends Artefakt {
    public Posuda(String oznaka, String materijal, PraistorijskoDoba doba) {
        super(oznaka, materijal, doba);
    }

    @Override
    public boolean iskopajArtefakt(int kvalifikacijaArheologa) {
        int verovatnocaUspeha = 9 * kvalifikacijaArheologa;
        Random random = new Random();
        if (random.nextInt(100) < verovatnocaUspeha)
            return true;
        else
            return false;
    }
}
