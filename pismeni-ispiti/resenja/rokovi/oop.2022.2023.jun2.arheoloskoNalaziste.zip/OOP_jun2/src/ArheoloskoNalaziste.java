import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ArheoloskoNalaziste {
    private List<Artefakt> listaArtefakta;

    public ArheoloskoNalaziste(List<Artefakt> listaArtefakta) {
        this.listaArtefakta = listaArtefakta;
    }

    public Artefakt iskopavanje(Arheolog arheolog){
        Random random = new Random();
        int ind = random.nextInt(listaArtefakta.size());

        Artefakt izabrani = listaArtefakta.get(ind);
        listaArtefakta.remove(ind);

        if (izabrani.iskopajArtefakt(arheolog.getKvalifikacija()))
            return izabrani;
        else{
            arheolog.oduzmiLicencu();
            return null;
        }
    }
}
