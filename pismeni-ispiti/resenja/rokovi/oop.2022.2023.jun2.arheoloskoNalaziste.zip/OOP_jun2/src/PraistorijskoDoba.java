public enum PraistorijskoDoba {
    KAMENO_DOBA, BRONZANO_DOBA, GVOZDENO_DOBA;

    public static PraistorijskoDoba odOznake(String str){
        switch (str){
            case "KD" : return KAMENO_DOBA;
            case "BD" : return BRONZANO_DOBA;
            case "GD" : return GVOZDENO_DOBA;
            default : throw new IllegalArgumentException("Nepoznato praistorijsko doba!");
        }
    }
}
