import java.util.Random;

public class Orudje extends Artefakt {
    public Orudje(String oznaka, String materijal, PraistorijskoDoba doba) {
        super(oznaka, materijal, doba);
    }

    @Override
    public boolean iskopajArtefakt(int kvalifikacijaArheologa) {
        int verovatnocaUspeha = 10 * kvalifikacijaArheologa;
        Random random = new Random();
        if (random.nextInt(100) < verovatnocaUspeha)
            return true;
        else
            return false;
    }
}
