import java.util.Comparator;

public class Arheolog implements Comparable<Arheolog> {
    private String imePrezime;
    private int kvalifikacija;
    private boolean licenciran;

    public Arheolog(String imePrezime, int kvalifikacija) {
        if (kvalifikacija < 1 && kvalifikacija > 10)
            throw new IllegalArgumentException("Nedopustena vrednost za kvalifikaciju arheologa!");
        this.imePrezime = imePrezime;
        this.kvalifikacija = kvalifikacija;
        this.licenciran = true;
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public int getKvalifikacija() {
        return kvalifikacija;
    }

    public boolean isLicenciran() {
        return licenciran;
    }

    public void oduzmiLicencu(){
        licenciran = false;
    }

    @Override
    public int compareTo(Arheolog a) {
        return this.imePrezime.compareTo(a.imePrezime);
    }

    @Override
    public String toString() {
        return imePrezime;
    }
}
