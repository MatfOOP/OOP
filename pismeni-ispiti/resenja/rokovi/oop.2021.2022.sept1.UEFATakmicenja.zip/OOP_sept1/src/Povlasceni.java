public interface Povlasceni {
}
