package resenja;

import java.util.Comparator;

public class KomparatorAutomobila implements Comparator<Automobil> {
    @Override
    public int compare(Automobil o1, Automobil o2) {
        if(o1 instanceof NovAutomobil)
            return -1;
        if(o2 instanceof NovAutomobil)
            return 1;

        return Double.compare(o2.getCena(), o1.getCena());
    }
}
