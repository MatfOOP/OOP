package resenja;

public enum TipAutomobila {
    LIMUZINA("Limuzina"),
    KARAVAN("Karavan"),
    HECBEK("Hecbek");

    private String tip;
    private double duzina;
    private TipAutomobila(String tip) {
        this.tip = tip;
    }

    public static TipAutomobila napraviTip(String tip, double duzina) {

        TipAutomobila t;
        if(tip.equalsIgnoreCase("limuzina")) {
            t = TipAutomobila.LIMUZINA;
        }
        else if(tip.equalsIgnoreCase("karavan")) {
            t = TipAutomobila.KARAVAN;
        }
        else if(tip.equalsIgnoreCase("hecbek")) {
            t = TipAutomobila.HECBEK;
        }
        else
            throw new IllegalArgumentException("Los argument!");

        t.duzina = duzina;
        return  t;
    }

    @Override
    public String toString() {
        return tip + " duzine " + duzina + "m.";
    }
}
