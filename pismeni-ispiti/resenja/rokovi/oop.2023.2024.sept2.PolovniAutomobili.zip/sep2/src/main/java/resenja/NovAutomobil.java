package resenja;

public class NovAutomobil extends Automobil{

    private int garancija;
    public static int prodati = 0;

    public NovAutomobil(int garancija, int id, double cena, double potrosnja, int brojVrata, String marka, String model, TipAutomobila tip) {
        super(id, cena, potrosnja, brojVrata, marka, model, tip);
        this.garancija = garancija;
    }

    @Override
    public String toString() {
        return super.toString() + " NOV sa garancijom " + garancija + "god.";
    }
}
