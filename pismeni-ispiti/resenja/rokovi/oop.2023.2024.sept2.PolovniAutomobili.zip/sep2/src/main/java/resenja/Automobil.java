package resenja;

public abstract class Automobil {
    private int id;
    private double cena;
    private double potrosnja;
    private int brojVrata;
    private String marka;
    private String model;
    private TipAutomobila tip;

    public Automobil(int id, double cena, double potrosnja, int brojVrata, String marka, String model, TipAutomobila tip) {
        this.id = id;
        this.cena = cena;
        this.potrosnja = potrosnja;
        this.brojVrata = brojVrata;
        this.marka = marka;
        this.model = model;
        this.tip = tip;
    }

    public double getCena() {
        return cena;
    }

    public String getMarka() {
        return marka;
    }

    public TipAutomobila getTip() {
        return tip;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "#" + id + " - "  + marka + " " + model + " - " + tip + " Potrosnja " + potrosnja + "l, broj vrata - " + brojVrata + ". "
                + "CENA: " + cena + "k $.";
    }
}
