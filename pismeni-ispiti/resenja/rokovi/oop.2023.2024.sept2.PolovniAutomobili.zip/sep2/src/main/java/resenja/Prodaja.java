package resenja;

public interface Prodaja {
    boolean prodaj(int id, double budzet);
}
