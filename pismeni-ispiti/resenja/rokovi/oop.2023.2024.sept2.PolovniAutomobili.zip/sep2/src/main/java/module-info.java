module org.example.sep2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens resenja to javafx.fxml;
    exports resenja;
}