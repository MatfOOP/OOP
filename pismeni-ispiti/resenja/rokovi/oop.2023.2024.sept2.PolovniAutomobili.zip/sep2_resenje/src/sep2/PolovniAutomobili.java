package sep2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;



public class PolovniAutomobili extends Application {

	private AutoKuca autoKuca;
	private double budzet;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {

		HBox root = new HBox(10);
		VBox hbLevi = new VBox(10);
		VBox hbDesni = new VBox(10);

		root.setPadding(new Insets(10));
		hbLevi.setPadding(new Insets(15));
		hbDesni.setPadding(new Insets(10));


		root.getChildren().addAll(hbLevi, hbDesni);

		Button btUcitaj = new Button("Ucitaj");
		Button btSortiraj = new Button("Sortiraj");

		Label lbKriterijum = new Label("Filter:");
		RadioButton rbCena = new RadioButton("Cena");
		RadioButton rbKaroserija = new RadioButton("Karoserija");
		RadioButton rbMarka = new RadioButton("Marka");


		ToggleGroup tg = new ToggleGroup();
		rbCena.setToggleGroup(tg);
		rbKaroserija.setToggleGroup(tg);
		rbMarka.setToggleGroup(tg);

		Label lbBudzet = new Label("Budzet: ");

		hbLevi.getChildren().addAll(btUcitaj, btSortiraj, lbKriterijum, rbCena, rbKaroserija, rbMarka, lbBudzet);

		TextField tfUnos = new TextField();
		Button btFiltriraj = new Button("Filtriraj");
		Button btKupi = new Button("Kupi");
		TextArea taIspis = new TextArea();
		Label lbPolovni = new Label("Prodati polovni: 0");
		Label lbNovi = new Label("Prodati novi: 0");
		Label lbRezultat = new Label();

		hbDesni.getChildren().addAll(tfUnos, btFiltriraj, btKupi, taIspis, lbPolovni, lbNovi, lbRezultat);

		tfUnos.setMaxWidth(200);
		hbDesni.setAlignment(Pos.TOP_RIGHT);

		btUcitaj.setOnAction(e -> {
			Path putanja = Paths.get("automobili.txt");
			try {
				List<String> linije = Files.readAllLines(putanja);
				String[] init = linije.get(0).split(" ");
				autoKuca = new AutoKuca(init[0]);

				double budzet = Double.parseDouble(init[1]);
				lbBudzet.setText("Budzet: " + budzet + "k $");
				this.budzet = budzet;

				linije.remove(0);

				for(String linija : linije) {
					String[] elements = linija.split(" ");
					int id = Integer.parseInt(elements[1]);
					String marka = elements[2];
					String model = elements[3];
					TipAutomobila tip = TipAutomobila.napraviTip(elements[4], Double.parseDouble(elements[5]));
					double potrosnja = Double.parseDouble(elements[6]);
					int brojVrata = Integer.parseInt(elements[7]);
					double cena = Double.parseDouble(elements[8]);

					if(elements[0].equalsIgnoreCase("N")) {
						int garancija = Integer.parseInt(elements[9]);
						autoKuca.add(new NovAutomobil(garancija, id, cena, potrosnja, brojVrata, marka, model, tip));
					}
					else {
						String stanje = "";
						for(int i = 9; i < elements.length; i++)
							stanje += elements[i] + " ";
						autoKuca.add(new PolovanAutomobil(id, cena, potrosnja, brojVrata, marka, model, tip, stanje));
					}
				}

				btUcitaj.setDisable(true);
				taIspis.setText(autoKuca.toString());


			} catch (IOException ioException) {
				ioException.printStackTrace();
			} catch (IllegalArgumentException e1) {
				System.err.println(e1.getMessage());
			}
		});

		btSortiraj.setOnAction(e -> {
			List<Automobil> automobili = autoKuca.getAutomobili();
			automobili.sort(new KomparatorAutomobila());
			autoKuca.setAutomobili(automobili);
			taIspis.setText(autoKuca.toString());
		});

		btKupi.setOnAction(e -> {
			int id = Integer.parseInt(tfUnos.getText());
			double cena = autoKuca.getCenaById(id);
			if(cena == -1) {
				lbRezultat.setText("Ne postoji taj id!");
				lbRezultat.setTextFill(Color.RED);
				return;
			}
			boolean uspesno = autoKuca.prodaj(id, this.budzet);

			if(uspesno) {
				this.budzet -= cena;
				lbBudzet.setText("Budzet: " + this.budzet + "k $");
				lbRezultat.setText("Uspesno prodat auto!");
				lbRezultat.setTextFill(Color.GREEN);
				lbPolovni.setText("Prodati polovni: " + PolovanAutomobil.prodati);
				lbNovi.setText("Prodati novi: " + NovAutomobil.prodati);

				taIspis.setText(autoKuca.toString());
			}
			else {
				lbRezultat.setText("Neuspesna prodaja!");
				lbRezultat.setTextFill(Color.RED);
			}

		});

		btFiltriraj.setOnAction(e -> {
			List<Automobil> automobili = autoKuca.getAutomobili();
			List<Automobil> filtrirani = new ArrayList<>();
			if(rbCena.isSelected()) {
				String[] cene = tfUnos.getText().split("-");
				double cenaDonja = Double.parseDouble(cene[0]);
				double cenaGornja = Double.parseDouble(cene[1]);
				for(Automobil a : automobili) {
					if(a.getCena() >= cenaDonja && a.getCena() <= cenaGornja)
						filtrirani.add(a);
				}
			}
			else if(rbKaroserija.isSelected()) {
				String karoserija = tfUnos.getText();
				for(Automobil a : automobili) {
					if(karoserija.equalsIgnoreCase("Hecbek") && a.getTip() == TipAutomobila.HECBEK
						|| karoserija.equalsIgnoreCase("Limuzina") && a.getTip() == TipAutomobila.LIMUZINA
						|| karoserija.equalsIgnoreCase("Karavan") && a.getTip() == TipAutomobila.KARAVAN)
						filtrirani.add(a);

				}
			}
			else if(rbMarka.isSelected()) {
				String marka = tfUnos.getText();
				for(Automobil a : automobili) {
					if(a.getMarka().equalsIgnoreCase(marka))
						filtrirani.add(a);
				}
			}

			filtrirani.sort(new KomparatorAutomobila());

			taIspis.setText("");
			for(Automobil a : filtrirani) {
				taIspis.appendText(a.toString() + "\n");
			}

		});



		Scene scene = new Scene(root, 750, 300);
		
		// Napravljena scenu postavljamo na pozornicu.
		primaryStage.setScene(scene);
		
		// Dajemo nasoj predstavi ime.
		primaryStage.setTitle("Prodaja automobila");
		
		// Otvaramo zavesu.
		primaryStage.show();
	}
}
