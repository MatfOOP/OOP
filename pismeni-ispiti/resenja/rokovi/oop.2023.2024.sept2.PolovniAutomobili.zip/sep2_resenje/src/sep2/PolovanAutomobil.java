package sep2;

public class PolovanAutomobil extends Automobil{
    private String stanje;

    public static int prodati = 0;

    public PolovanAutomobil(int id, double cena, double potrosnja, int brojVrata, String marka, String model, TipAutomobila tip, String stanje) {
        super(id, cena, potrosnja, brojVrata, marka, model, tip);
        this.stanje = stanje;
    }

    @Override
    public String toString() {
        return super.toString() + " POLOVAN, stanje: " + stanje + ".";
    }
}
