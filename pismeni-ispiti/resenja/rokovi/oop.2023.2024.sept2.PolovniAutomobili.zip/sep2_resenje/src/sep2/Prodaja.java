package sep2;

public interface Prodaja {
    boolean prodaj(int id, double budzet);
}
