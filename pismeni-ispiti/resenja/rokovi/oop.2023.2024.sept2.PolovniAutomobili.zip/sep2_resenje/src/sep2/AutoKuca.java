package sep2;

import java.util.*;

public class AutoKuca implements Prodaja{
    private String naziv;
    private List<Automobil> automobili;
    private double zarada;


    public AutoKuca(String naziv) {
        this.naziv = naziv;
        this.automobili = new ArrayList<>();
        zarada = 0;
    }

    @Override
    public boolean prodaj(int id, double budzet) {
        for(Automobil a : automobili) {
            if(a.getId() != id)
                continue;

            if(a.getCena() < budzet) {
                automobili.remove(a);
                zarada += a.getCena();
                if(a instanceof NovAutomobil)
                    NovAutomobil.prodati++;
                else
                    PolovanAutomobil.prodati++;


                return  true;
            }
            else
                return false;
        }

        return false;
    }

    public List<Automobil> getAutomobili() {
        return automobili;
    }

    public double getCenaById(int id) {
        for(Automobil a : automobili)
            if(a.getId() == id)
                return a.getCena();

        return -1;
    }

    public void setAutomobili(List<Automobil> automobili) {
        this.automobili = automobili;
    }

    public void add(Automobil a) {
        automobili.add(a);
    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner("\n");
        for(Automobil a : automobili)
            sj.add(a.toString());
        return sj.toString();
    }
}
