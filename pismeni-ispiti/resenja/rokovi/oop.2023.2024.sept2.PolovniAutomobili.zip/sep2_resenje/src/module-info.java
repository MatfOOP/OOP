module module_name {
    requires javafx.fxml;
    requires javafx.controls;

    opens sep2;

}