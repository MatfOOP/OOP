package resenja;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class Koncert extends Application  {
    private final List<Bend> bendovi = new LinkedList<>();
    private static boolean ucitano = false;

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) {
        HBox koren = new HBox(10);
        koren.setPadding(new Insets(10));

        VBox vBoxLevi = new VBox(10);
        VBox vBoxDesni =  new VBox(10);

        koren.getChildren().addAll(vBoxLevi, vBoxDesni);

        // vBoxLevi
        Button btUcitaj = new Button("Ucitaj bendove");
        Label lbImePosetioca = new Label("Ime posetioca");
        TextField tfImePosetioca = new TextField();
        Label lbZanr = new Label("Zeljeni zanr");

        RadioButton rbPop = new RadioButton("POP");
        RadioButton rbRok = new RadioButton("ROK");
        RadioButton rbRep = new RadioButton("REP");
        ToggleGroup tg1 = new ToggleGroup();
        rbPop.setToggleGroup(tg1);
        rbRok.setToggleGroup(tg1);
        rbRep.setToggleGroup(tg1);

        Label lbSlobodnoVreme = new Label("Slobodno vreme");
        TextField tfVreme = new TextField();
        Label lbJezik = new Label("Zna engleski");
        
        RadioButton rbDa = new RadioButton("DA");
        RadioButton rbNe = new RadioButton("NE");
        ToggleGroup tg2 = new ToggleGroup();
        rbDa.setToggleGroup(tg2);
        rbNe.setToggleGroup(tg2);
        
        Button btDodaj = new Button("Dodaj posetioca");
        Button btOcisti = new Button("Ocisti");

        vBoxLevi.getChildren().addAll(
                btUcitaj, lbImePosetioca, tfImePosetioca,
                lbZanr, rbPop, rbRok, rbRep,
                lbSlobodnoVreme, tfVreme, lbJezik,
                rbDa, rbNe, btDodaj, btOcisti
        );

        // vBoxDesni
        TextField tfIzvodjac = new TextField();
        Button btIspis = new Button("Ispisi bend i posetioce");
        Label lbSortirano = new Label("Odaberite kriterijum za sortiranje");

        RadioButton rbBrPoseta = new RadioButton("broj posetilaca (opadajuce)");
        RadioButton rbVrPocetka = new RadioButton("vreme pocetka (rastuce)");
        ToggleGroup tg3 = new ToggleGroup();
        rbBrPoseta.setToggleGroup(tg3);
        rbVrPocetka.setToggleGroup(tg3);

        Button btPrikaz = new Button("Prikazi sortirano");
        TextArea taIspis = new TextArea();

        vBoxDesni.getChildren().addAll(
          tfIzvodjac, btIspis, lbSortirano, rbBrPoseta, rbVrPocetka, btPrikaz, taIspis
        );

        // akcije
        btOcisti.setOnAction(arg -> {
            tfImePosetioca.clear();
            tfVreme.clear();
            tfIzvodjac.clear();
            rbDa.setSelected(false);
            rbNe.setSelected(false);
            rbBrPoseta.setSelected(false);
            rbVrPocetka.setSelected(false);
            rbRep.setSelected(false);
            rbPop.setSelected(false);
            rbRok.setSelected(false);
            taIspis.clear();
        });
        
        btUcitaj.setOnAction(arg -> {
            if (!ucitano) {
                ucitano = true;

                Path putanja = Paths.get("podaci.txt");

                try {
                    List<String> linije = Files.readAllLines(putanja);

                    for (String linija : linije) {
                        String[] niz = linija.split(", ");

                        String nazivBenda = niz[0];
                        String nazivMuzicara = niz[1];
                        int vremePocetka = Integer.parseInt(niz[2]);
                        int vremeKraja = Integer.parseInt(niz[3]);
                        MuzickiZanr zanr;
                        try {
                            int pom = Integer.parseInt(niz[4]);
                            zanr = MuzickiZanr.odrediZanr(pom);
                        } catch (NumberFormatException e) {
                            zanr = MuzickiZanr.odrediZanr(niz[4]);
                        }

                        boolean straniBend = false;
                        if (niz.length == 6) {
                            straniBend = true;
                        }

                        Muzicar muzicar = new Muzicar(nazivMuzicara, zanr);
                        Bend bend = new Bend(nazivBenda, muzicar, vremePocetka, vremeKraja, straniBend);
                        bendovi.add(bend);
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            ispisiBendove(taIspis);
        });

        btDodaj.setOnAction(arg -> {
            String ime = tfImePosetioca.getText();
            MuzickiZanr zanr;
            if (rbRok.isSelected()) {
                zanr = MuzickiZanr.ROK;
            } else if (rbPop.isSelected()) {
                zanr = MuzickiZanr.POP;
            } else {
                zanr = MuzickiZanr.REP;
            }

            String vreme = tfVreme.getText();
            String[] niz = vreme.split("-");
            int pocetnoVreme = Integer.parseInt(niz[0]);
            int krajVreme = Integer.parseInt(niz[1]);
            boolean znaEngleski = rbDa.isSelected() ? true : false;
            Posetilac posetilac;
            if (znaEngleski) {
                posetilac = new PosetilacKojiZnaEngleski(ime, zanr, pocetnoVreme, krajVreme);
            } else {
                posetilac = new Posetilac(ime, zanr, pocetnoVreme, krajVreme);
            }

            for (Bend bend : bendovi) {
                if (bend.getPevac().zanr == zanr &&
                        bend.getVremePocetka() >= pocetnoVreme && bend.getVremeKraja() <= krajVreme) {
                    if (!(posetilac instanceof PosetilacKojiZnaEngleski) && bend.isStraniBend()) {
                        continue;
                    }
                    taIspis.clear();
                    taIspis.setText("Posetilac " + ime + " ce slusati " + bend.getNaziv());
                    bend.dodajPosetioca(posetilac);
                    break;
                }
            }
        });

        btIspis.setOnAction(arg -> {
            taIspis.clear();
            String nazivBenda = tfIzvodjac.getText();
            for (Bend bend : bendovi) {
                if (bend.getNaziv().equals(nazivBenda)) {
                    taIspis.appendText(bend.toString());
                    break;
                }
            }
        });

        btPrikaz.setOnAction(arg -> {
            if (rbBrPoseta.isSelected()) {
                bendovi.sort(Bend.komparatorPosetioci);
                ispisiBendove(taIspis);
            } else {
                bendovi.sort(Bend.komparatorVremena);
                ispisiBendove(taIspis);
            }
        });

        // scena
        Scene scena = new Scene(koren, 700, 450);
        stage.setTitle("Koncert");
        stage.setScene(scena);
        stage.show();
    }

    private void ispisiBendove(TextArea taIspis) {
        taIspis.clear();
        for (Bend bend : bendovi) {
            taIspis.appendText(bend.toString());
        }
    }

}
