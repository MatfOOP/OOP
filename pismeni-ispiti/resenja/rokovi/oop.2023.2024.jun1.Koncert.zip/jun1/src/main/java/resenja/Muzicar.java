package resenja;

public class Muzicar extends Osoba {

    public Muzicar(String ime, MuzickiZanr zanr) {
        super(ime, zanr);
    }

    @Override
    public String toString() {
        return "Ja sam muzicar " + ime + " i sviram u " + zanr + " bendu";
    }
}
