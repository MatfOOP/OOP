package resenja;

public interface EngleskiJezik {
    String pozdravNaEngleskom();
}
