package resenja;

public class PosetilacKojiZnaEngleski extends Posetilac implements EngleskiJezik {
    public PosetilacKojiZnaEngleski(String ime, MuzickiZanr zanr, int pocetakSlobodnogVremena, int krajSlobodnogVremena) {
        super(ime, zanr, pocetakSlobodnogVremena, krajSlobodnogVremena);
    }

    @Override
    public String pozdravNaEngleskom() {
        return "I am visitor " + ime + " and I like to listen to "
                + MuzickiZanr.prevediNaEngleski(zanr) + " music";
    }

    @Override
    public String toString() {
        return pozdravNaEngleskom();
    }
}
