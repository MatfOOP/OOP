module org.example.jun1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens resenja to javafx.fxml;
    exports resenja;
}