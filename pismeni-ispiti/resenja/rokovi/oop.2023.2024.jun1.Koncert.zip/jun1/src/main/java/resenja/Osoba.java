package resenja;

public abstract class Osoba {
    protected String ime;
    protected MuzickiZanr zanr;

    public Osoba(String ime, MuzickiZanr zanr) {
        this.ime = ime;
        this.zanr = zanr;
    }
}
