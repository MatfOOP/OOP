package zadatak;

public class Posetilac extends Osoba {
    private int pocetakSlobodnogVremena;
    private int krajSlobodnogVremena;

    public int getPocetakSlobodnogVremena() {
        return pocetakSlobodnogVremena;
    }

    public int getKrajSlobodnogVremena() {
        return krajSlobodnogVremena;
    }

    public Posetilac(String ime, MuzickiZanr zanr, int pocetakSlobodnogVremena, int krajSlobodnogVremena) {
        super(ime, zanr);
        this.pocetakSlobodnogVremena = pocetakSlobodnogVremena;
        this.krajSlobodnogVremena = krajSlobodnogVremena;
    }

    @Override
    public String toString() {
        return "Ja sam posetilac " + ime + " i volim da slusam " + zanr + " muziku";
    }
}
