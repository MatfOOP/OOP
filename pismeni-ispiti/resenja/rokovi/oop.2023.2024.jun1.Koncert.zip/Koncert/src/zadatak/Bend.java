package zadatak;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Bend {
    private String naziv;
    private Muzicar pevac;
    private List<Posetilac> posetioci;
    private int vremePocetka;
    private int vremeKraja;
    private boolean straniBend;


    public static Comparator<Bend> komparatorPosetioci = (o1, o2) -> {
        return o2.posetioci.size() - o1.posetioci.size();
    };

    public static Comparator<Bend> komparatorVremena = (o1, o2) -> {
        return o1.getVremePocetka() - o2.getVremePocetka();
    };

    public String getNaziv() {
        return naziv;
    }

    public Muzicar getPevac() {
        return pevac;
    }

    public List<Posetilac> getPosetioci() {
        return posetioci;
    }

    public boolean isStraniBend() {
        return straniBend;
    }

    public Bend(String naziv, Muzicar pevac, int vremePocetka, int vremeKraja, boolean straniBend) {
        this.naziv = naziv;
        this.pevac = pevac;
        this.posetioci = new LinkedList<>();
        this.vremePocetka = vremePocetka;
        this.vremeKraja = vremeKraja;
        this.straniBend = straniBend;
    }

    public int getVremePocetka() {
        return vremePocetka;
    }

    public int getVremeKraja() {
        return vremeKraja;
    }

    public void dodajPosetioca(Posetilac p) {
        posetioci.add(p);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("-----------------------------------------------------------------------\n");
        sb.append("Bend: ").append(naziv)
                .append(", vreme: ").append(vremePocetka).append("-").append(vremeKraja)
                .append("\n");
        sb.append(pevac).append("\n");
        for(Posetilac p : posetioci) {
            sb.append(p).append("\n");
        }
        sb.append("-----------------------------------------------------------------------\n");

        return sb.toString();
    }
}
