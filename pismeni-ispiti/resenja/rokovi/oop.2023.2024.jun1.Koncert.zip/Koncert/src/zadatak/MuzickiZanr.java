package zadatak;

public enum MuzickiZanr {
    POP,
    ROK,
    REP;

    public static <T> MuzickiZanr odrediZanr(T argument) {
		if (argument instanceof String) {
		    String s1 = (String) argument;
		    switch (s1) {
		        case "pop": return POP;
		        case "rok": return ROK;
		        case "rep": return REP;
		        default: throw new IllegalArgumentException("ZANR NIJE VALIDAN!");
		    }
		} else {
		    int broj = (Integer) argument;
		    System.out.println(broj);
		    switch (broj) {
		        case 0: return POP;
		        case 1: return ROK;
		        case 2: return REP;
		        default: throw new IllegalArgumentException("ZANR NIJE VALIDAN!");
        	}
    	}
    }

    public static String prevediNaEngleski(MuzickiZanr zanr) {
        switch (zanr) {
            case POP: return "POP";
            case REP: return "RAP";
            default: return "ROCK";
        }
    }
}
