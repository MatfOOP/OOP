package zadatak;

public interface EngleskiJezik {
    String pozdravNaEngleskom();
}
