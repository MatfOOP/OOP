module Koncert {

    requires javafx.fxml;
    requires javafx.controls;

    opens zadatak;
}