package resenja;

import java.util.List;

public class OsnovniKorisnik extends Korisnik implements KorisnickeAktivnosti {
    public OsnovniKorisnik(String username) {
        super(username);
    }

    @Override
    public boolean lajkujObjavu(Objava<Integer, String> objava) {
        // Proverava da li je kreator objave u listi pratilaca
        List<Korisnik> lista = objava.getKreatorObjave().getPratioci();
        for(Korisnik k : lista){
            if(k.getUsername().equals(this.getUsername())){
                objava.lajkuj();
                return true;
            }
        }


        return false; // Ne može lajkovati ako nije pratilac
    }


    @Override
    public String toString() {
        return "Korisnik " + getUsername();
    }
}
