module org.example.sep1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens resenja to javafx.fxml;
    exports resenja;
}