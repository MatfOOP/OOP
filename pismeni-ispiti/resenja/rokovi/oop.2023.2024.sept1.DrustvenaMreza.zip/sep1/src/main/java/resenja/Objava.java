package resenja;

public class Objava<T1, T2> {
    private T1 idObjave;
    private T2 sadrzajObjave;
    private TipObjave tipObjave;
    private Korisnik kreatorObjave;
    private int brojLajkova;

    public Objava(T1 idObjave, T2 sadrzajObjave, TipObjave tipObjave, Korisnik kreatorObjave) {
        this.idObjave = idObjave;
        this.sadrzajObjave = sadrzajObjave;
        this.tipObjave = tipObjave;
        this.kreatorObjave = kreatorObjave;
        this.brojLajkova = 0;
    }

    public T1 getIdObjave() {
        return idObjave;
    }

    public Korisnik getKreatorObjave() {
        return kreatorObjave;
    }

    public int getBrojLajkova() {
        return brojLajkova;
    }

    public void lajkuj() {
        brojLajkova++;
    }

    @Override
    public String toString() {
        return "Objava #" + idObjave + ", " + brojLajkova + " lajk(ova), " + kreatorObjave + " je objavio (" + tipObjave + "): " + sadrzajObjave + '\n';
    }
}


