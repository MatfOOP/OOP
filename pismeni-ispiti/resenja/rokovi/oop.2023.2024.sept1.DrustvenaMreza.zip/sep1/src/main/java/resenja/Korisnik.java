package resenja;

import java.util.ArrayList;
import java.util.List;

public abstract class Korisnik {
    private String username;
    private List<Korisnik> pratioci;

    public Korisnik(String username) {
        this.username = username;
        this.pratioci = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public List<Korisnik> getPratioci() {
        return pratioci;
    }

    public void addPratilac(Korisnik k){
        pratioci.add(k);
    }

}

