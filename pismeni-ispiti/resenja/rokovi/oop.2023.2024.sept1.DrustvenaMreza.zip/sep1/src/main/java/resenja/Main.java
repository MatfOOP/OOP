package resenja;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
    private List<Objava<Integer, String>> objave = new ArrayList<>();
    private List<Korisnik> korisnici = new ArrayList<>();


    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        HBox root = new HBox(10);
        root.setPadding(new Insets(10, 10, 10, 10));

		/*
			Nas prozor cemo organizovati kao:
			HBox :
		 		VBox 			<- vbLeft
		 		VBox            <- vbRight
		*/
        VBox vbLeft = new VBox(10);
        Button btnUcitaj = new Button("Ucitaj objave");
        ToggleGroup tg = new ToggleGroup();
        RadioButton rbLikes = new RadioButton("Sortiraj po lajkovima");
        Button btnOsveziPrikaz = new Button("Osvezi prikaz");
        TextArea feedArea = new TextArea();
        vbLeft.getChildren().addAll(btnUcitaj, rbLikes, btnOsveziPrikaz, feedArea);

        VBox vbRight = new VBox(10);
        Label lblUsername = new Label("Username:");
        TextField tfUsername = new TextField();

        Label lblNovaObjava = new Label("Nova objava:");
        TextField tfNovaObjava = new TextField();
        Button btnNovaObjava = new Button("Dodaj objavu");

        Label lblObrisiObjavu = new Label("Obrisi objavu sa id:");
        TextField tfObrisiObjavuId = new TextField();
        Button btnObrisiObjavu = new Button("Obrisi objavu");

        Label lblLajkujObjavu = new Label("Lajkuj objavu sa id:");
        TextField tfLajkujObjavu = new TextField();
        Button btnLajkuj = new Button("Lajkuj objavu");
        Label lblUpozorenje = new Label("");
        lblUpozorenje.setTextFill(Color.RED);

        Button btnOcistiPolja = new Button("Ocisti");


        vbRight.getChildren().addAll(lblUsername, tfUsername, lblNovaObjava, tfNovaObjava, btnNovaObjava, lblObrisiObjavu, tfObrisiObjavuId, btnObrisiObjavu, lblLajkujObjavu, tfLajkujObjavu, btnLajkuj, btnOcistiPolja, lblUpozorenje);


        root.getChildren().addAll(vbLeft, vbRight);


        btnOcistiPolja.setOnAction(e -> {

            lblUpozorenje.setText("");
            tfLajkujObjavu.clear();
            tfNovaObjava.clear();
            tfUsername.clear();
            tfObrisiObjavuId.clear();

        });

        btnUcitaj.setOnAction(e -> {
            try (BufferedReader br = new BufferedReader(new FileReader("objave.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    boolean admin = false;
                    String[] parts = line.split(", ");
                    if(parts.length == 5){
                        admin = true;
                    }
                    String username = parts[0];
                    int idObjave = Integer.parseInt(parts[1]);
                    TipObjave tip = TipObjave.kreirajIzStringa(parts[2]);
                    String sadrzaj = parts[3];

                    Korisnik k;
                    if(admin) {
                        System.out.println("Admin: " + username);
                        k = new AdminKorisnik(username);
                    } else {
                        k = new OsnovniKorisnik(username);
                    }
                    korisnici.add(k);

                    Objava<Integer, String> objava = new Objava<>(idObjave, sadrzaj, tip, k);
                    objave.add(objava);
                    feedArea.appendText(objava.toString());
                    btnUcitaj.setDisable(true);

                }
            } catch (IOException ex) {
                feedArea.setText("Greska prilikom ucitavanja objava.");
            }

            try (BufferedReader br = new BufferedReader(new FileReader("pratioci.txt"))) {
                String linija;
                while ((linija = br.readLine()) != null) {
                    String[] delovi = linija.split(": ");

                    String korisnickoIme = delovi[0].trim();
                    Korisnik korisnikKogaPrate = proveriKorisnika(korisnickoIme);
                    String[] pratioci = delovi[1].split(",");

                    for (String pratilac : pratioci) {
                        pratilac = pratilac.trim();
                        Korisnik pratilacObj = proveriKorisnika(pratilac);
                        korisnikKogaPrate.addPratilac(pratilacObj);
                    }

                }

            } catch (IOException ex) {
                feedArea.setText("Greska prilikom ucitavanja objava.");
            }
        });

        btnNovaObjava.setOnAction(e -> {

            String username = tfUsername.getText().trim();
            String sadrzaj = tfNovaObjava.getText().trim();

            if (!username.isEmpty() && !sadrzaj.isEmpty()) {

                Korisnik user = proveriKorisnika(username);
                int idObjave = objave.size() + 1;
                Objava<Integer, String> objava = new Objava<>(idObjave, sadrzaj, TipObjave.OSTALO, user);
                objave.add(objava);
                feedArea.setText(formatirajObjave());
            }

        });
        
        btnObrisiObjavu.setOnAction(e -> {
            String username = tfUsername.getText();
            Integer idObjave = Integer.parseInt(tfObrisiObjavuId.getText());
            Objava objava = nadjiObjavu(idObjave);
            Korisnik user = proveriKorisnika(username);

            if(user instanceof AdminKorisnik) {
                if(objava != null){
                    ((AdminKorisnik) user).obrisiObjavu(objava, objave);
                    feedArea.setText(formatirajObjave());
                } else {
                    lblUpozorenje.setText("Ne postoji objava sa tim ID-jem!");
                }
            }

            else {
                lblUpozorenje.setText("Niste admin korisnik!");
            }
        });

        btnLajkuj.setOnAction(e -> {
            String username = tfUsername.getText().trim();
            Integer idObjave = Integer.parseInt(tfLajkujObjavu.getText());
            Objava objava = nadjiObjavu(idObjave);
            Korisnik user = proveriKorisnika(username);

            if(objava != null) {
                System.out.println("usao ovde");
                if (user instanceof AdminKorisnik)
                    ((AdminKorisnik) user).lajkujObjavu(objava);
                else if (!((OsnovniKorisnik) user).lajkujObjavu(objava)) {
                    lblUpozorenje.setText("Korisnik " + username + " ne prati korisika " + objava.getKreatorObjave().getUsername());
                }
            }
            else {
                lblUpozorenje.setText("Ne postoji objava sa tim ID-jem!");
            }

            feedArea.setText(formatirajObjave());
        });

        btnOsveziPrikaz.setOnAction(e -> {
           if(rbLikes.isSelected()){
               objave.sort(new KomparatorPoLajkovima());
               feedArea.setText(formatirajObjave());

           }
        });

        Scene scene = new Scene(root, 700, 400);


        primaryStage.setTitle("Drustvena mreža");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private Objava nadjiObjavu(Integer idObjave) {

        for(Objava o: objave){
            if(o.getIdObjave().equals(idObjave))
                return o;
        }

        return null;

    }

    Korisnik proveriKorisnika(String username){

        for(Korisnik k : korisnici){
            if(k.getUsername().equals(username)){
                return k;
            }
        }

        Korisnik k1 = new OsnovniKorisnik(username);
        korisnici.add(k1);
        return k1;

    }

    String formatirajObjave(){

        StringBuilder sb = new StringBuilder();
        for(Objava o : objave){
            sb.append(o);
        }

        return sb.toString();
    }

}

