package resenja;

import java.util.Comparator;


public class KomparatorPoLajkovima implements Comparator<Objava<Integer, String>> {

    @Override
    public int compare(Objava<Integer, String> o1, Objava<Integer, String> o2) {

        int lajkoviPoredjenje = Integer.compare(o2.getBrojLajkova(), o1.getBrojLajkova());
        // Ako broj lajkova nije isti, vratiti rezultat poređenja po lajkova
        if (lajkoviPoredjenje != 0) {
            return lajkoviPoredjenje;
        }

        if(o1.getKreatorObjave() instanceof AdminKorisnik && o2.getKreatorObjave() instanceof OsnovniKorisnik){
            return -1;
        } else if(o1.getKreatorObjave() instanceof OsnovniKorisnik && o2.getKreatorObjave() instanceof AdminKorisnik){
            return 1;
        } else {
            return 0;
        }

    }
}

