package resenja;

public interface KorisnickeAktivnosti {

    boolean lajkujObjavu(Objava<Integer, String> objava);

}
