package zadatak;

public interface KorisnickeAktivnosti {

    boolean lajkujObjavu(Objava<Integer, String> objava);

}
