package zadatak;


import java.util.List;

public class AdminKorisnik extends Korisnik implements KorisnickeAktivnosti {

    public AdminKorisnik(String username) {
        super(username);
    }

    @Override
    public boolean lajkujObjavu(Objava<Integer, String> objava) {
        // Admin korisnik može lajkovati bilo koju objavu
        objava.lajkuj();
        return true;
    }

    public boolean obrisiObjavu(Objava<Integer, String> objava, List<Objava<Integer, String>> objave) {
        // Admin korisnik može brisati bilo koju objavu
        return objave.remove(objava);
    }

    @Override
    public String toString() {
        return "Admin korisnik " + getUsername();
    }
}


