package zadatak;

public enum TipObjave {
    HRANA,
    PUTOVANJE,
    ZABAVA,
    OSTALO;

    public static TipObjave kreirajIzStringa(String tip){
        switch (tip.toUpperCase()) {
            case "HRANA":
                return HRANA;
            case "PUTOVANJE":
                return PUTOVANJE;
            case "ZABAVA":
                return ZABAVA;
            case "OSTALO":
                return OSTALO;
            default:
                throw new IllegalArgumentException("Nevažeći tip objave: " + tip);
        }
    }
}

