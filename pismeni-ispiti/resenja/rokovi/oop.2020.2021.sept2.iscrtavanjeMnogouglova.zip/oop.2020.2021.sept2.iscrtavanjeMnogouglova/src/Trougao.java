public class Trougao extends Mnogougao {
    public Trougao(double[][] koordinate){
        super(koordinate, new Tacka((koordinate[0][0]+koordinate[1][0]+koordinate[2][0])/3,
                (koordinate[0][1]+koordinate[1][1]+koordinate[2][1])/3));
    }

    public Trougao(Tacka A, Tacka B, Tacka C){
        super(new Tacka[]{A, B, C}, new Tacka((A.getX()+B.getX()+C.getX())/3, (A.getY()+B.getY()+C.getY())/3));
    }

    @Override
    public double povrsina() {
        double stranice[] = super.duzineStranica();
        double poluobim = super.obim() / 2;

        return Math.sqrt(poluobim * (poluobim-stranice[0]) * (poluobim-stranice[1]) * (poluobim-stranice[2]));
    }

    private static double round(double x, double n){
        return Math.round(x * Math.pow(10, n)) / Math.pow(10, n);
    }

    public boolean jednakostranicni(){
        double stranice[] = super.duzineStranica();

        return (round(stranice[0], 2) == round(stranice[1], 2)) && (round(stranice[1], 2) == round(stranice[2], 2));
    }
}
