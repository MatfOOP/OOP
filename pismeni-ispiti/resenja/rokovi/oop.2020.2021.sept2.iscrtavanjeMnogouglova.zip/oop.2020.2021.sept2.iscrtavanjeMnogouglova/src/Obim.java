public interface Obim {
    public double obim();
}
