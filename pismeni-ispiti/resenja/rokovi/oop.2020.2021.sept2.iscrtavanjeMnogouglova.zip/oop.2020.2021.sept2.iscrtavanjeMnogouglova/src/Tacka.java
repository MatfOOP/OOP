public class Tacka {
    private double x;
    private double y;

    public Tacka(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Tacka(Tacka t){
        this(t.x, t.y);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public double rastojanje(Tacka t){
        return Math.sqrt(Math.pow(x - t.x, 2) + Math.pow(y - t.y, 2));
    }
}
