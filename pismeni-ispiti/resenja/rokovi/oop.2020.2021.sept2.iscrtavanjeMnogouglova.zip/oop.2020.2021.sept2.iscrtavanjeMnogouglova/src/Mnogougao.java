import java.util.Arrays;

public abstract class Mnogougao implements Obim, Povrsina{
    private Tacka[] temena;
    private Tacka centar;

    public Mnogougao(Tacka[] temena, Tacka centar){
        temena = new Tacka[temena.length];
        for (int i = 0; i < temena.length; i++)
            temena[i] = new Tacka(temena[i]);

        this.centar = new Tacka(centar);
    }

    public Mnogougao(double[][] koordinate, Tacka centar){
        temena = new Tacka[koordinate.length];
        for (int i = 0; i < koordinate.length; i++)
            temena[i] = new Tacka(koordinate[i][0], koordinate[i][1]);

        this.centar = new Tacka(centar);
    }

    public Tacka getCentar() {
        return centar;
    }

    public Tacka[] getTemena() {
        return temena;
    }

    public double[] getXKoordinate(){
        double[] xKoord = new double[temena.length];

        for (int i = 0; i < temena.length; i++)
            xKoord[i] = temena[i].getX();

        return xKoord;
    }

    public double[] getYKoordinate(){
        double[] yKoord = new double[temena.length];

        for (int i = 0; i < temena.length; i++)
            yKoord[i] = temena[i].getY();

        return yKoord;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("[");
        for (int i = 0; i < temena.length; i++){
            sb.append(temena[i].toString());
            if(i != temena.length-1)
                sb.append(", ");
        }
        sb.append("]");

        return sb.toString();
    }

    public double[] duzineStranica(){
        double[] stranice = new double[temena.length];

        for (int i = 0; i < temena.length-1; i++)
            stranice[i] = temena[i].rastojanje(temena[i+1]);
        stranice[temena.length-1] = temena[0].rastojanje(temena[temena.length-1]);

        return stranice;
    }

    @Override
    public double obim() {
        double[] stranice = this.duzineStranica();

        double obim = 0;
        for (int i = 0; i < stranice.length; i++)
            obim += stranice[i];

        return obim;
    }
}
