public interface Povrsina {
    public double povrsina();
}
