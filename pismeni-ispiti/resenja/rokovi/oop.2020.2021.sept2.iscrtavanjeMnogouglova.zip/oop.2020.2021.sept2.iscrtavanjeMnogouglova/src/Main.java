import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main extends Application {
    Map<String, Mnogougao> mnogouglovi = new TreeMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));
        vBoxRoot.setAlignment(Pos.CENTER_RIGHT);

        Canvas canvas = new Canvas(500, 300);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        Button button = new Button("Iscrtaj");
        TextArea textArea = new TextArea();

        vBoxRoot.getChildren().addAll(canvas, textArea, button);

        //----------------------------------------------------------------------------

        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for (Map.Entry<String, Mnogougao> mn : mnogouglovi.entrySet()){
                    String name = mn.getKey();
                    Mnogougao m = mn.getValue();

                    double[] xKoord = m.getXKoordinate();
                    double[] yKoord = m.getYKoordinate();

                    if(m instanceof Trougao){
                        if(((Trougao) m).jednakostranicni())
                            gc.setFill(Color.BLUE);
                        else
                            gc.setFill(Color.GREEN);

                        gc.fillPolygon(xKoord, yKoord, 3);

                        gc.setFill(Color.BLACK);
                        gc.fillText(name, m.getCentar().getX(), m.getCentar().getY());
                    }
                    else {
                        if(((Pravougaonik)m).kvadrat())
                            gc.setFill(Color.RED);
                        else
                            gc.setFill(Color.ORANGE);

                        gc.fillPolygon(xKoord, yKoord, 4);

                        gc.setFill(Color.BLACK);
                        gc.fillText(name, m.getCentar().getX(), m.getCentar().getY());
                    }

                    textArea.appendText(mn.getKey() + ": obim = " + round(mn.getValue().obim(), 2) + ", povrsina = " + round(mn.getValue().povrsina(), 2) + "\n");
                }
            }
        });

        //----------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 520, 550);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Iscrtavanje mnogouglova");
        primaryStage.show();

        ucitaj(mnogouglovi);
        ispisi(mnogouglovi);
    }

    private static double round(double x, double n){
        return Math.round(x * Math.pow(10, n)) / Math.pow(10, n);
    }

    private static void ucitaj(Map<String, Mnogougao> mnogouglovi){
        try (Scanner sc = new Scanner(new File("src/mnogouglovi.txt"))) {
            while(sc.hasNextLine()) {
                String linija = sc.nextLine();
                String[] strs = linija.split(" ");

                double[][] koordinate = new double[(strs.length-1)/2][2];
                for (int i = 0; i < koordinate.length; i++) {
                    koordinate[i][0] = Double.parseDouble(strs[2 * i + 1]);
                    koordinate[i][1] = Double.parseDouble(strs[2 * i + 2]);
                }

                switch (strs[0].charAt(0)) {
                    case 'T':
                        mnogouglovi.put(strs[0], new Trougao(koordinate));
                        break;
                    case 'P':
                        mnogouglovi.put(strs[0], new Pravougaonik(koordinate));
                        break;
                    default:
                        throw new IOException("Datoteka nije u ispravnom formatu!");
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static <K, V> void ispisi(Map<K, V> mapa){
        for (Map.Entry<K, V> entry : mapa.entrySet())
            System.out.println(entry.getKey() + ": " + entry.getValue());
    }
}
