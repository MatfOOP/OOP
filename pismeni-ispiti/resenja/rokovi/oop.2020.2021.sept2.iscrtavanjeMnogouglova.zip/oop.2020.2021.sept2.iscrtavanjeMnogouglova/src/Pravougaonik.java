public class Pravougaonik extends Mnogougao{
    public Pravougaonik(double[][] koordinate){
        super(koordinate, new Tacka((koordinate[0][0]+koordinate[2][0])/2, (koordinate[0][1]+koordinate[2][1])/2));
    }

    public Pravougaonik(Tacka A, Tacka B, Tacka C, Tacka D){
        super(new Tacka[]{A, B, C, D}, new Tacka((A.getX()+C.getX())/2, (A.getY()+C.getY())/2));
    }

    @Override
    public double povrsina() {
        double stranice[] = super.duzineStranica();

        return stranice[0] * stranice[1];
    }

    public boolean kvadrat(){
        double stranice[] = super.duzineStranica();

        return stranice[0] == stranice[1];
    }
}
