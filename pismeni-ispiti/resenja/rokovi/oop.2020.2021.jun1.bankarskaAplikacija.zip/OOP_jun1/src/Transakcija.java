
public class Transakcija {
    private TipTransakcije tipTransakcije;
    private double iznos;
    private Valuta valuta;
    private String datum;

    public Transakcija(TipTransakcije tipTransakcije, double iznos, Valuta valuta, String datum) {
        this.tipTransakcije = tipTransakcije;
        this.iznos = iznos;
        this.valuta = valuta;
        this.datum = datum;
    }

    public TipTransakcije getTipTransakcije() {
        return tipTransakcije;
    }

    public double getIznos() {
        return iznos;
    }

    public Valuta getValuta() {
        return valuta;
    }

    public String getDatum() {
        return datum;
    }

    public int getMesec() {
        String[] strs = datum.split("/");
        return Integer.parseInt(strs[1]);
    }

    public int getGodina(){
        String[] strs = datum.split("/");
        return Integer.parseInt(strs[2]);
    }

    @Override
    public String toString() {
        return tipTransakcije + " " + iznos + " " + valuta + " " + datum;
    }
}
