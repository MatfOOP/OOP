import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Main extends Application {
    private Map<String, Racun> racuni = new TreeMap<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        Button buttonUcitaj = new Button("Ucitaj");

        HBox hBoxUcitaj = new HBox(10);
        hBoxUcitaj.setAlignment(Pos.BASELINE_RIGHT);
        hBoxUcitaj.getChildren().addAll(buttonUcitaj);

        Label labelRacuni = new javafx.scene.control.Label("Dostupni racuni:");

        HBox hBoxTop = new HBox(10);
        TextArea textAreaRacuni = new TextArea("");
        HBox hBoxMiddle = new HBox(10);
        TextArea textAreaIzvestaj = new TextArea("");

        Button buttonIzvestaj = new Button("Izvestaj");

        HBox hBoxIzvestaj = new HBox(10);
        hBoxIzvestaj.setAlignment(Pos.BASELINE_RIGHT);
        hBoxIzvestaj.getChildren().addAll(buttonIzvestaj);

        vBoxRoot.getChildren().addAll(hBoxUcitaj, labelRacuni, textAreaRacuni, hBoxMiddle, textAreaIzvestaj, hBoxIzvestaj);

        //-------------------------------------------------------------------------------------

        Label labelID = new Label("Broj racuna:");
        TextField textFieldID = new TextField("");
        Label labelMesec = new Label("Mesec:");
        TextField textFieldMesec = new TextField("");
        Label labelGodina = new Label("Godina:");
        TextField textFieldGodina = new TextField("");

        hBoxMiddle.getChildren().addAll(labelID, textFieldID, labelMesec, textFieldMesec, labelGodina, textFieldGodina);

        //-------------------------------------------------------------------------------------

        buttonUcitaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Path path = Paths.get("src/transakcije.txt");

                try {
                    List<String> linije = Files.readAllLines(path);

                    for(String l : linije){
                        String[] strs = l.split(" ");
                        String ID = strs[0];
                        TipTransakcije tipTransakcije = TipTransakcije.odSkracenice(strs[1].charAt(0));
                        double iznos = Double.parseDouble(strs[2]);
                        Valuta valuta = Valuta.odSkracenice(strs[3]);
                        String datum = strs[4];

                        Racun racun = null;
                        if(racuni.containsKey(ID))
                            racun = racuni.get(ID);
                        else{
                            if(ID.startsWith("1")){
                                racun = new DinarskiRacun(ID);
                                racuni.put(ID, racun);
                            }
                            else if(ID.startsWith("8")){
                                racun = new DevizniRacun(ID, Valuta.USD);
                                racuni.put(ID, racun);
                            }
                            else if(ID.startsWith("9")){
                                racun = new DevizniRacun(ID, Valuta.EUR);
                                racuni.put(ID, racun);
                            }
                            else
                                throw new RuntimeException("Datoteka nije u dobrom formatu");
                        }

                        switch (tipTransakcije){
                            case UPLATA: racun.uplata(iznos, valuta, datum); break;
                            case ISPLATA: racun.isplata(iznos, valuta, datum); break;
                            case POTROSNJA:racun.potrosnja(iznos, valuta, datum); break;
                        }
                    }

                    for(Racun r: racuni.values())
                            textAreaRacuni.appendText(r.toString() + "\n");
                } catch (IOException e) {
                    textAreaRacuni.setText(e.getMessage());
                }
            }
        });

        buttonIzvestaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textAreaIzvestaj.clear();

                String ID = textFieldID.getText();
                Integer mesec = textFieldMesec.getText().length() == 0? null : Integer.parseInt(textFieldMesec.getText());
                Integer godina = textFieldGodina.getText().length() == 0 ? null : Integer.parseInt(textFieldGodina.getText());

                Racun racun = racuni.get(ID);
                if(racun == null)
                    textAreaIzvestaj.setText("Nepostojeci broj racuna!");
                else {
                    List<Transakcija> transakcije = racun.filtrirajTransakcije(mesec, godina);

                    for (Transakcija t : transakcije)
                        textAreaIzvestaj.appendText(t.toString() + "\n");

                    if(mesec == null && godina == null) {
                        textAreaIzvestaj.appendText("\n" + "Stanje na racunu = " + String.format("%.2f", racun.getStanje()));
                        if(racun instanceof DinarskiRacun)
                            textAreaIzvestaj.appendText(" RSD");
                        else
                            textAreaIzvestaj.appendText(((DevizniRacun) racun).getValuta().toString());
                    }
                }
            }
        });

        //-------------------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 770, 500);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Bankarska aplikacija");
        primaryStage.show();
    }
}
