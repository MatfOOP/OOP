public class DinarskiRacun extends Racun{
    public DinarskiRacun(String ID) {
        super(ID);
    }

    @Override
    public void uplata(double iznos, Valuta valuta, String datum) {
        if(valuta != Valuta.RSD)
            throw new IllegalArgumentException("Nisu moguce uplate na dinarski " + this.getID() + " racun u valuti " + valuta);

        this.dodajTransakciju(new Transakcija(TipTransakcije.UPLATA, iznos, valuta, datum), +iznos);
    }

    public void isplata(double iznos, Valuta valuta, String datum){
        double iznos_din = iznos;

        if(valuta != Valuta.RSD) {
            iznos_din += 0.003;             //provizija u visini 3% za podizanje na bankomatima u inostranstvu

            switch (valuta) {
                case EUR: iznos_din *= 120.15;
                case USD: iznos_din *= 99.10;
            }
        }
        this.dodajTransakciju(new Transakcija(TipTransakcije.ISPLATA, iznos, valuta, datum), -iznos_din);
    }

    public void potrosnja(double iznos, Valuta valuta, String datum){
        double iznos_din = iznos;
        if(valuta != Valuta.RSD) {
            switch (valuta) {
                case EUR:
                    iznos_din *= 120.15;
                case USD:
                    iznos_din *= 99.10;
            }
        }
        this.dodajTransakciju(new Transakcija(TipTransakcije.POTROSNJA, iznos, valuta, datum), -iznos_din);
    }

    @Override
    public String toString() {
        return this.getID() + " - dinarski";
    }
}
