public enum TipTransakcije {
    UPLATA('U'), ISPLATA('I'), POTROSNJA('P');

    private char skracenica;

    TipTransakcije(char skracenica) {
        this.skracenica = skracenica;
    }

    public static TipTransakcije odSkracenice(char skracenica){
        skracenica = Character.toUpperCase(skracenica);

        switch (skracenica){
            case 'U' : return UPLATA;
            case 'I' : return ISPLATA;
            case 'P' : return POTROSNJA;
            default: throw new IllegalArgumentException("Nedozvoljena skracenica za tip transakcije");
        }
    }

    @Override
    public String toString() {
        switch (this){
            case UPLATA: return "uplata";
            case ISPLATA: return "isplata";
            case POTROSNJA: return "potrosnja";
            default: return "";
        }
    }
}
