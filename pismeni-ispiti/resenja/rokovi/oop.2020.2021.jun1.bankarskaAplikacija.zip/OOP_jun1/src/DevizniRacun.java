public class DevizniRacun extends Racun{
    private Valuta valuta;

    public DevizniRacun(String ID, Valuta valuta) {
        super(ID);
        this.valuta = valuta;
    }

    public Valuta getValuta() {
        return valuta;
    }

    @Override
    public void uplata(double iznos, Valuta valuta, String datum) {
        if(valuta != this.valuta)
            throw new IllegalArgumentException("Nisu moguce uplate na devizni racun " + this.getID() + " u valuti " + valuta);

        this.dodajTransakciju(new Transakcija(TipTransakcije.UPLATA, iznos, valuta, datum), +iznos);
    }

    public void isplata(double iznos, Valuta valuta, String datum){
        if(valuta != this.valuta)
            throw new RuntimeException("Nije moguca isplata u valuti " + valuta + " sa deviznog racuna " + this.getID());

        this.dodajTransakciju(new Transakcija(TipTransakcije.ISPLATA, iznos, valuta, datum), -iznos);
    }

    public void potrosnja(double iznos, Valuta valuta, String datum){
        if(valuta != this.valuta)
            throw new RuntimeException("Nije moguca potrosnja u valuti " + valuta + " sa deviznog racuna " + this.getID());

        this.dodajTransakciju(new Transakcija(TipTransakcije.POTROSNJA, iznos, valuta, datum), -iznos);
    }

    @Override
    public String toString() {
        return this.getID() + " - devizni(" + valuta + ")";
    }
}
