public enum Valuta {
    RSD("RSD"), EUR("EUR"), USD("USD");

    private String skracenica;

    Valuta(String skracenica) {
        this.skracenica = skracenica;
    }

    public static Valuta odSkracenice(String skracenica){
        skracenica = skracenica.toUpperCase();

        switch (skracenica) {
            case "RSD": return RSD;
            case "EUR": return EUR;
            case "USD": return USD;
            default: throw new IllegalArgumentException("Nedozvoljena skracenica za valutu");
        }
    }
}
