import java.util.ArrayList;
import java.util.List;

public abstract class Racun {
    private String ID;
    private double stanje;
    private List<Transakcija> transakcije;

    public Racun(String ID) {
        this.ID = ID;
        this.stanje = 0;
        transakcije = new ArrayList<>();
    }

    public String getID() {
        return ID;
    }

    public double getStanje() {
        return stanje;
    }

    public List<Transakcija> getTransakcije() {
        return transakcije;
    }

    public void dodajTransakciju(Transakcija t, double iznos){
        transakcije.add(t);
        stanje += iznos;
    }

    public abstract void uplata(double iznos, Valuta valuta, String datum);
    public abstract void isplata(double iznos, Valuta valuta, String datum);
    public abstract void potrosnja(double izos, Valuta valuta, String datum);

    public List<Transakcija> filtrirajTransakcije(Integer mesec, Integer godina){
        if(mesec != null && godina != null) {
            List<Transakcija> filtriraneTransakcije = new ArrayList<>();
            for (Transakcija t : transakcije) {
                if (t.getMesec() == mesec && t.getGodina() == godina)
                    filtriraneTransakcije.add(t);
            }
            return filtriraneTransakcije;
        }
        else
            return this.transakcije;
    }
}
