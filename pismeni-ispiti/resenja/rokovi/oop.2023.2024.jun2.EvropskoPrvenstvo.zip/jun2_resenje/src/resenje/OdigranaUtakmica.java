package resenje;

public class OdigranaUtakmica extends Utakmica{
    private RezultatUtakmice rezultat;

    OdigranaUtakmica(String tim1, String tim2, String vreme, RezultatUtakmice rezultat) {
        super(tim1, tim2, vreme);
        this.rezultat = rezultat;
    }

    public RezultatUtakmice getRezultat() {
        return rezultat;
    }

    @Override
    public String toString() {
        return "Utakmica izmedju " + tim1 + " i " + tim2 + " odigrana je u " + vreme + "h. " + rezultat;
    }
}
