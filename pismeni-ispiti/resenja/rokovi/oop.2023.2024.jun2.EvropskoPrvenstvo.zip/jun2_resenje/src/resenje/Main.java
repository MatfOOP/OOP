package resenje;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Main extends Application {

    private EvropskoPrvenstvo prvenstvo;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        HBox root = new HBox(10);
        root.setPadding(new Insets(10));

        VBox vbLevi = new VBox(20);
        VBox vbDesni = new VBox(10);

        root.getChildren().addAll(vbLevi, vbDesni);

        Button btUcitaj = new Button("Ucitaj");
        Button btSortiraj = new Button("Sortiraj");


        HBox hbRadio = new HBox(10);

        RadioButton rb1 = new RadioButton("1");
        RadioButton rbX = new RadioButton("X");
        RadioButton rb2 = new RadioButton("2");

        ToggleGroup tg = new ToggleGroup();
        rb1.setToggleGroup(tg);
        rbX.setToggleGroup(tg);
        rb2.setToggleGroup(tg);

        hbRadio.getChildren().addAll(rb1, rbX, rb2);

        Button btIspisi = new Button("Ispisi");
        btIspisi.setAlignment(Pos.BASELINE_CENTER);
        Button btOcisti = new Button("Ocisti");

        vbLevi.getChildren().addAll(btUcitaj, btSortiraj, hbRadio, btIspisi, btOcisti);

        HBox hbMali = new HBox(10);

        TextField tfUnos = new TextField();
        Button btSimuliraj = new Button("Simuliraj");

        hbMali.getChildren().addAll(tfUnos, btSimuliraj);

        TextArea taIspis = new TextArea();

        vbDesni.getChildren().addAll(hbMali, taIspis);

        btUcitaj.setOnAction(e -> {
            btUcitaj.setDisable(true);
            Path filePath = Paths.get("./src/utakmice.txt");

            try {
                List<String> lines = Files.readAllLines(filePath);
                String[] tokens = lines.get(0).split(", ");
                prvenstvo = new EvropskoPrvenstvo(tokens[0], tokens[1]);

                lines.remove(0);
                for(String line : lines) {
                    String[] attributes = line.split(", ");

                    if(attributes.length == 3) {
                        prvenstvo.dodajUtakmicu(new SimuliranaUtakmica(attributes[0], attributes[1], attributes[2]));
                    }
                    else {
                        RezultatUtakmice rez = RezultatUtakmice.napraviIzRezultata(attributes[3]);
                        prvenstvo.dodajUtakmicu(new OdigranaUtakmica(attributes[0], attributes[1], attributes[2], rez));
                    }

                }

            }
            catch (IOException ex) {
                ex.printStackTrace();
            }

            taIspis.appendText(prvenstvo.toString());

        });

        btOcisti.setOnAction(e -> {
            taIspis.setText("");
            tfUnos.setText("");
            tg.selectToggle(null);
        });

        btSortiraj.setOnAction(e -> {
            List<Utakmica> utakmice = prvenstvo.getUtakmice();
            utakmice.sort(new KomparatorUtakmica());

            taIspis.setText("");
            for (Utakmica u : utakmice)
                taIspis.appendText(u + "\n");

        });

        btSimuliraj.setOnAction(e -> {
            String text = tfUnos.getText();
            String[] tokens = text.split(", ");
            taIspis.setText(prvenstvo.simulirajUtakmicu(tokens[0], tokens[1], Integer.parseInt(tokens[2])));
        });

        btIspisi.setOnAction(e -> {
            if(rb1.isSelected()) {
                taIspis.setText(prvenstvo.nadjiUtakmice(RezultatUtakmice.TIM1));
            }
            if(rbX.isSelected()) {
                taIspis.setText(prvenstvo.nadjiUtakmice(RezultatUtakmice.X));
            }
            if(rb2.isSelected()) {
                taIspis.setText(prvenstvo.nadjiUtakmice(RezultatUtakmice.TIM2));
            }
        });

        Scene scene = new Scene(root, 700, 250);
        primaryStage.setTitle("Evropsko Prvenstvo");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
