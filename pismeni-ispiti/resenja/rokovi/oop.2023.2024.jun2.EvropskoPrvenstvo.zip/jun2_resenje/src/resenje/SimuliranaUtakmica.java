package resenje;

import java.util.Random;

public class SimuliranaUtakmica extends Utakmica implements SimulacijaUtakmice{

    private RezultatUtakmice rezultat;

    public SimuliranaUtakmica(String tim1, String tim2, String vreme) {
        super(tim1, tim2, vreme);
        rezultat = null;
    }

    public SimuliranaUtakmica(SimuliranaUtakmica s) {
        this(s.tim1, s.tim2, s.vreme);
        rezultat = s.rezultat;
    }

    @Override
    public RezultatUtakmice getRezultat() {
        return rezultat;
    }

    @Override
    public void simulirajIgranjeUtakmice(int n) {
        int golovi1 = 0;
        int golovi2 = 0;
        Random rand = new Random();

        for(int i = 0; i < n; i++) {
            if(rand.nextDouble() < 0.3)
                golovi1++;
            if(rand.nextDouble() < 0.3)
                golovi2++;
        }

        rezultat = RezultatUtakmice.napraviIzRezultata(golovi1 + ":" + golovi2);
    }

    @Override
    public String toString() {
        if (rezultat == null)
            return "Utakmica izmedju " + tim1 + " i " + tim2 + " jos uvek nije simulirana!";
        else
            return "Utakmica izmedju " + tim1 + "  i " + tim2 + " zakazana za " + vreme + "h je simulirana. " + rezultat;
    }
}
