package resenje;

public abstract class Utakmica {
    protected String tim1, tim2, vreme;

    Utakmica(String tim1, String tim2, String vreme) {
        this.tim1 = tim1;
        this.tim2 = tim2;
        this.vreme = vreme;
    }

    public String getTim1() {
        return tim1;
    }

    public String getTim2() {
        return tim2;
    }

    public abstract RezultatUtakmice getRezultat();
}

