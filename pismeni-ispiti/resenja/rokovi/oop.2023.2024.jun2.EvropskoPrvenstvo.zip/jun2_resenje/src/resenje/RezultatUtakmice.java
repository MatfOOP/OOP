package resenje;

public enum RezultatUtakmice {

    TIM1('1'),
    X('X'),
    TIM2('2');

    private char rez;

    RezultatUtakmice(char rez) {
        this.rez = rez;
    }

    public static RezultatUtakmice napraviIzRezultata(String rezultat) throws IllegalArgumentException{
        String[] tokeni = rezultat.split(":");
        if(tokeni.length != 2)
            throw new IllegalArgumentException("Los rezultat!");

        try {
            Integer golovi1 = Integer.parseInt(tokeni[0]);
            Integer golovi2 = Integer.parseInt(tokeni[1]);

            if(golovi1 == golovi2)
                return RezultatUtakmice.X;
            if(golovi1 > golovi2)
                return RezultatUtakmice.TIM1;
            else
                return RezultatUtakmice.TIM2;
        }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException("Los format za golove!");
        }
    }

    @Override
    public String toString() {
        if(rez == '1')
            return "Pobedio je tim 1!";
        if(rez == 'X')
            return "Bilo je nereseno!";
        else
            return "Pobedio je tim 2!";
    }
}

