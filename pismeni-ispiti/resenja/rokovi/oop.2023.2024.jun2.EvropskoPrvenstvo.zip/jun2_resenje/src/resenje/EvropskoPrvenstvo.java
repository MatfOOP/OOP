package resenje;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class EvropskoPrvenstvo {
    private String mestoOdrzavanja;
    private String datumOdrzavanja;
    private List<Utakmica> utakmice;

    public EvropskoPrvenstvo(String mestoOdrzavanja, String datumOdrzavanja) {
        this.mestoOdrzavanja = mestoOdrzavanja;
        this.datumOdrzavanja = datumOdrzavanja;
        utakmice = new ArrayList<>();
    }

    public String getMestoOdrzavanja() {
        return mestoOdrzavanja;
    }

    public List<Utakmica> getUtakmice() {
        return utakmice;
    }

    public String getDatumOdrzavanja() {
        return datumOdrzavanja;
    }

    public void dodajUtakmicu(Utakmica u) {
        utakmice.add(u);
    }

    public String simulirajUtakmicu(String tim1, String tim2, int n) {
        for (Utakmica u : utakmice) {
            if (u.getTim1().equals(tim1) && u.getTim2().equals(tim2)) {
                if (u instanceof OdigranaUtakmica) {
                    return "Utakmica izmedju " + tim1 + " i " + tim2 + " je vec odigrana!";
                }
                SimuliranaUtakmica su = (SimuliranaUtakmica) u;
                su.simulirajIgranjeUtakmice(n);
                return "Utakmica izmedju " + tim1 + " i " + tim2 + " je simulirana! " + su.getRezultat();
            }
        }
        return "Ne postoji utakmica izmedju timova " + tim1 + " i " + tim2 + "!";
    }

    public String nadjiUtakmice(RezultatUtakmice rez) {
        StringJoiner sj = new StringJoiner("\n");
        for (Utakmica u : utakmice)
            if(u.getRezultat() == rez)
                sj.add(u.toString());
        return sj.toString();
    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner("\n");
        for (Utakmica u : utakmice)
            sj.add(u.toString());
        return sj.toString();
    }
}
