package resenje;

public interface SimulacijaUtakmice {
    void simulirajIgranjeUtakmice(int n);
}

