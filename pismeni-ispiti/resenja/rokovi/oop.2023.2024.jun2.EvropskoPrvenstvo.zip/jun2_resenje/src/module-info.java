module EvropskoPrvenstvo {

    requires javafx.fxml;
    requires javafx.controls;

    opens resenje;
}