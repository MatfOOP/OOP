package resenja;

import java.util.Comparator;

public class KomparatorUtakmica implements Comparator<Utakmica> {
    @Override
    public int compare(Utakmica o1, Utakmica o2) {
        if(o1 instanceof OdigranaUtakmica && o2 instanceof SimuliranaUtakmica)
            return -1;
        if(o1 instanceof SimuliranaUtakmica && o2 instanceof OdigranaUtakmica)
            return 1;

        RezultatUtakmice rez1 = o1.getRezultat();
        if(rez1 == null)
            return 1;
        RezultatUtakmice rez2 = o2.getRezultat();
        if(rez2 == null)
            return -1;

        int rez1int = 0, rez2int = 0;
        if(rez1 == RezultatUtakmice.TIM1)
            rez1int = 1;
        if(rez1 == RezultatUtakmice.X)
            rez1int = 2;
        if(rez1 == RezultatUtakmice.TIM2)
            rez1int = 3;

        if(rez2 == RezultatUtakmice.TIM1)
            rez2int = 1;
        if(rez2 == RezultatUtakmice.X)
            rez2int = 2;
        if(rez2 == RezultatUtakmice.TIM2)
            rez2int = 3;

        return Integer.compare(rez1int, rez2int);
    }
}
