package resenja;

public interface SimulacijaUtakmice {
    void simulirajIgranjeUtakmice(int n);
}
