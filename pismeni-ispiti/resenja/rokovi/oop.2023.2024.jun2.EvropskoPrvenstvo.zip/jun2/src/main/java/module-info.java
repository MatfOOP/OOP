module org.example.jun2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens resenja to javafx.fxml;
    exports resenja;
}