public enum Ukus {
    COKOLADA, VANILA, PISTACI, MALINA;
}
