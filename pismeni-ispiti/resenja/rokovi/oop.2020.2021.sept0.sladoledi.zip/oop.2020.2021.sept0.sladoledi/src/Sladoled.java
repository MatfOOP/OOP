public abstract class Sladoled {
    private String ime;

    public Sladoled(String ime){
        this.ime = ime;
    }

    public String getIme() {
        return ime;
    }

    public abstract int cena();
}
