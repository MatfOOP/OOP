import java.util.*;

public class SladoledCrnaOvca extends Sladoled{
    private NacinServiranja nacinServiranja;
    private List<Ukus> ukusi;

    public SladoledCrnaOvca(String ime, NacinServiranja nacinServiranja, List<Ukus> ukusi){
        super(ime);
        this.nacinServiranja = nacinServiranja;
        this.ukusi = new LinkedList<>(ukusi);
    }

    @Override
    public String toString() {
        return this.getIme() + " [Crna Ovca] ukusi: " + this.ukusi + " serviranje: " + this.nacinServiranja;
    }

    @Override
    public int cena() {
        return 100 + 70 * this.ukusi.size();
    }
}
