import java.util.Comparator;

public class KomparatorSladoleda implements Comparator<Sladoled> {
    @Override
    public int compare(Sladoled s1, Sladoled s2) {
        if (s1 instanceof SladoledCrnaOvca && s2 instanceof SladoledIceBox)
            return -1;
        else if (s1 instanceof SladoledIceBox && s2 instanceof SladoledCrnaOvca)
            return +1;
        else{
            if(s1.cena() != s2.cena())
                return -(s1.cena() - s2.cena());
            else
                return s1.getIme().compareTo(s2.getIme());
        }
    }
}
