public enum NacinServiranja {
    STAPIC, KORNET, CASA;
}
