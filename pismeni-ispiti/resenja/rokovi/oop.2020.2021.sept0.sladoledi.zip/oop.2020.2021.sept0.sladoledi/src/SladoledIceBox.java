import java.util.LinkedList;
import java.util.List;

public class SladoledIceBox extends Sladoled {
    private Baza baza;
    private List<Toping> topinzi;

    public SladoledIceBox(String ime, Baza baza, List<Toping> topinzi){
        super(ime);
        this.baza = baza;
        this.topinzi = new LinkedList<>(topinzi);
    }

    @Override
    public String toString() {
        return this.getIme() + " [Ice Box] baza: " + this.baza + " topinzi: " + this.topinzi;
    }

    @Override
    public int cena() {
        int zbirCenaTopinga = 0;
        for (Toping t : topinzi)
            zbirCenaTopinga += t.getCena();

        return 200 + zbirCenaTopinga;
    }
}
