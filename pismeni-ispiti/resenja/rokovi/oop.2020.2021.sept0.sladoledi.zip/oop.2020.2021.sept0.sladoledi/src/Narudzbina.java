import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Narudzbina extends Application {
    private List<Sladoled> narudzbine = new LinkedList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxIzbori1 = new HBox(10);
        HBox hBoxIzbori2 = new HBox(10);
        TextArea textAreaNarudzbine = new TextArea();
        Button buttonSacuvajNarudzbinu = new Button("Sacuvaj narudzbinu");

        vBoxRoot.getChildren().addAll(hBoxIzbori1, hBoxIzbori2, textAreaNarudzbine, buttonSacuvajNarudzbinu);

        //----------------------------------------------------------------------------------------------------

        VBox vBoxCrnaOvca = new VBox(10);
        VBox vBoxIceBox = new VBox(10);

        hBoxIzbori1.getChildren().addAll(vBoxCrnaOvca, vBoxIceBox);

        //---------------------------------------------------------------------------------------------------

        Label labelCrnaOvca = new Label("Crna Ovca");
        HBox hBoxIzboriCrnaOvca = new HBox(10);

        vBoxCrnaOvca.getChildren().addAll(labelCrnaOvca, hBoxIzboriCrnaOvca);

        //---------------------------------------------------------------------------------------------------

        VBox vBoxNacinPosluzivanja = new VBox(10);
        VBox vBoxUkusi = new VBox(10);

        hBoxIzboriCrnaOvca.getChildren().addAll(vBoxNacinPosluzivanja, vBoxUkusi);

        //---------------------------------------------------------------------------------------------------

        Label labelNacinPosluzivanja = new Label("Nacin posluzivanja");
        RadioButton radioButtonKornet = new RadioButton("Kornet");
        RadioButton radioButtonCasa = new RadioButton("Casa");
        RadioButton radioButtonStapic = new RadioButton("Stapic");

        ToggleGroup toggleGroupNacinPosluzivanja = new ToggleGroup();
        radioButtonKornet.setToggleGroup(toggleGroupNacinPosluzivanja);
        radioButtonCasa.setToggleGroup(toggleGroupNacinPosluzivanja);
        radioButtonStapic.setToggleGroup(toggleGroupNacinPosluzivanja);

        radioButtonKornet.setSelected(true);

        vBoxNacinPosluzivanja.getChildren().addAll(labelNacinPosluzivanja, radioButtonKornet, radioButtonCasa, radioButtonStapic);

        //---------------------------------------------------------------------------------------------------

        Label labelUkusi = new Label("Ukusi");
        RadioButton radioButtonUkusiCokolada = new RadioButton("Cokolada");
        RadioButton radioButtonUkusiPistaci = new RadioButton("Pistaci");
        RadioButton radioButtonUkusiVanila = new RadioButton("Vanila");
        RadioButton radioButtonUkusiMalina = new RadioButton("Malina");

        vBoxUkusi.getChildren().addAll(labelUkusi, radioButtonUkusiCokolada, radioButtonUkusiPistaci, radioButtonUkusiVanila, radioButtonUkusiMalina);

        //---------------------------------------------------------------------------------------------------

        Label labelIceBox = new Label("Ice Box");
        HBox hBoxIzboriIceBox = new HBox(10);

        vBoxIceBox.getChildren().addAll(labelIceBox, hBoxIzboriIceBox);

        //---------------------------------------------------------------------------------------------------

        VBox vBoxBaza = new VBox(10);
        VBox vBoxTopinzi = new VBox(10);

        hBoxIzboriIceBox.getChildren().addAll(vBoxBaza, vBoxTopinzi);

        //---------------------------------------------------------------------------------------------------

        Label labelBaza = new Label("Baza");
        RadioButton radioButtonBazaVanila = new RadioButton("Vanila");
        RadioButton radioButtonBazaCokolada = new RadioButton("Cokolada");
        RadioButton radioButtonBazaMiks = new RadioButton("Miks");

        ToggleGroup toggleGroupBaza = new ToggleGroup();
        radioButtonBazaCokolada.setToggleGroup(toggleGroupBaza);
        radioButtonBazaVanila.setToggleGroup(toggleGroupBaza);

        radioButtonBazaVanila.setSelected(true);

        vBoxBaza.getChildren().addAll(labelBaza, radioButtonBazaVanila, radioButtonBazaCokolada, radioButtonBazaMiks);

        //---------------------------------------------------------------------------------------------------

        Label labelTopinzi = new Label("Topinzi");
        RadioButton radioButtonCokoladneMrvice = new RadioButton("Cokoladne mrvice");
        RadioButton radioButtonKaramela = new RadioButton("Karamela");
        RadioButton radioButtonVisnja = new RadioButton("Visnja");
        RadioButton radioButtonBombonice = new RadioButton("Bombonice");

        vBoxTopinzi.getChildren().addAll(labelTopinzi, radioButtonCokoladneMrvice, radioButtonKaramela, radioButtonVisnja, radioButtonBombonice);

        //--------------------------------------------------------------------------------------------------

        Label labelIme = new Label("Ime:");
        TextField textFieldIme = new TextField();
        Button buttonDodajCrnuOvcu = new Button("Dodaj Crnu Ovcu");
        Button buttonDodajIceBox = new Button("Dodaj Ice Box");

        hBoxIzbori2.getChildren().addAll(labelIme, textFieldIme, buttonDodajCrnuOvcu, buttonDodajIceBox);

        //--------------------------------------------------------------------------------------------------

        buttonDodajCrnuOvcu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String ime = textFieldIme.getText();

                if(ime.isEmpty()) {
                    textAreaNarudzbine.setText("Molimo upisite Vase ime!");
                    return;
                }

                List<Ukus> ukusi = new LinkedList<>();
                if(radioButtonUkusiCokolada.isSelected())
                    ukusi.add(Ukus.COKOLADA);
                if(radioButtonUkusiPistaci.isSelected())
                    ukusi.add(Ukus.PISTACI);
                if(radioButtonUkusiVanila.isSelected())
                    ukusi.add(Ukus.VANILA);
                if(radioButtonUkusiMalina.isSelected())
                    ukusi.add(Ukus.MALINA);

                if(ukusi.isEmpty()) {
                    textAreaNarudzbine.setText("Molimo dodajte neki ukus!");
                    return;
                }

                NacinServiranja nacinServiranja = null;
                if(radioButtonKornet.isSelected())
                    nacinServiranja = NacinServiranja.KORNET;
                else if(radioButtonCasa.isSelected())
                    nacinServiranja = NacinServiranja.CASA;
                else
                    nacinServiranja = NacinServiranja.STAPIC;

                SladoledCrnaOvca noviSladoled = new SladoledCrnaOvca(ime, nacinServiranja, ukusi);
                narudzbine.add(noviSladoled);

                ispisiNarudzbine(textAreaNarudzbine);
            }
        });

        buttonDodajIceBox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String ime = textFieldIme.getText();

                if(ime.isEmpty()) {
                    textAreaNarudzbine.setText("Molimo upisite Vase ime!");
                    return;
                }

                Baza baza = null;
                if(radioButtonBazaVanila.isSelected())
                    baza = Baza.VANILA;
                else if(radioButtonBazaCokolada.isSelected())
                    baza = Baza.COKOLADA;
                else
                    baza = Baza.MIKS;

                List<Toping> topinzi = new LinkedList<>();
                if(radioButtonCokoladneMrvice.isSelected())
                    topinzi.add(Toping.COKOLADNE_MRVICE);
                if(radioButtonKaramela.isSelected())
                    topinzi.add(Toping.KARAMELA);
                if(radioButtonVisnja.isSelected())
                    topinzi.add(Toping.VISNJA);
                if(radioButtonBombonice.isSelected())
                    topinzi.add(Toping.BOMBONICE);

                SladoledIceBox noviSladoled = new SladoledIceBox(ime, baza, topinzi);
                narudzbine.add(noviSladoled);

                ispisiNarudzbine(textAreaNarudzbine);
            }
        });

        buttonSacuvajNarudzbinu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(narudzbine.isEmpty()){
                    textAreaNarudzbine.setText("Dodajte neki sladoled!");
                    return;
                }

                KomparatorSladoleda komparator = new KomparatorSladoleda();
                Collections.sort(narudzbine, komparator);

                try (PrintWriter writer = new PrintWriter(new File("src/narudzbine.txt"))) {
                    for (Sladoled s : narudzbine)
                        writer.println(s);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //--------------------------------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 500, 450);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Narudzbina sladoleda");
        primaryStage.show();
    }

    private void ispisiNarudzbine(TextArea textArea){
        int ukupnaCena = 0;

        textArea.clear();
        for (Sladoled s : narudzbine) {
            textArea.appendText(s.toString() + "\n");
            ukupnaCena += s.cena();
        }

        textArea.appendText("====================================================\n");
        textArea.appendText("Ukupna cena: " + ukupnaCena);
    }
}
