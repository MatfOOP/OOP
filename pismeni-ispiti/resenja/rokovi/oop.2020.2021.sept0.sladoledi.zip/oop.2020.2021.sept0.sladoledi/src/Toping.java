public enum Toping {
    COKOLADNE_MRVICE(100), KARAMELA(70), VISNJA(70), BOMBONICE(80);

    private int cena;

    private Toping(int cena){
        this.cena = cena;
    }

    public int getCena() {
        return cena;
    }
}
