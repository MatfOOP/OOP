public enum Baza {
    VANILA, COKOLADA, MIKS;
}
