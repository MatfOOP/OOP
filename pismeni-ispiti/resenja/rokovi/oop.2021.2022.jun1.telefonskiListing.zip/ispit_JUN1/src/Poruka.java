public class Poruka extends Usluga {
    private String tekst;
    private boolean poslata;

    public Poruka(String vreme, Broj brojOd, Broj brojKa, String tekst, boolean poslata) {
        super(vreme, brojOd, brojKa);
        this.tekst = tekst;
        this.poslata = poslata;
    }

    @Override
    public double cena() {
        if(brojOd.isFiksniTelefon() || brojKa.isFiksniTelefon())
            throw new IllegalArgumentException("Nije moguce poslati poruku sa i na broj fiksnog telefona");

        if (poslata){
            if(brojOd.istaDrzava(brojKa))
                return 3;
            else
                return 20;
        }
        else
            return 0;
    }

    @Override
    public String toString() {
        return super.toString() + " \t" + (poslata ? "POSLATO\t\t" : "NIJE POSLATO\t") + cena() + "din";
    }
}
