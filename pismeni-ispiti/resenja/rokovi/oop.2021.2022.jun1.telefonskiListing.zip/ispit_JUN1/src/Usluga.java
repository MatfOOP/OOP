public abstract class Usluga implements Comparable<Usluga>{
    private String vreme;
    protected Broj brojOd, brojKa;

    public Usluga(String vreme, Broj brojOd, Broj brojKa) {
        this.vreme = vreme;
        this.brojOd = new Broj(brojOd);
        this.brojKa = new Broj(brojKa);
    }

    public String getVreme() {
        return vreme;
    }

    public Broj getBrojOd() {
        return brojOd;
    }

    public Broj getBrojKa() {
        return brojKa;
    }

    public abstract double cena();

    @Override
    public int compareTo(Usluga u) {
        return this.getVreme().compareTo(u.getVreme());     //format: "YYYY-MM-DD HH:MM:SS"
    }

    @Override
    public String toString() {
        return vreme + "\t" + brojOd + " -> " + brojKa;
    }
}
