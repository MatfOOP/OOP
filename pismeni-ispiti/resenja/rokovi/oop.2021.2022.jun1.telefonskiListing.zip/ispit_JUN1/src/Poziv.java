public class Poziv extends Usluga {
    private int trajanjeS;

    public Poziv(String vreme, Broj brojOd, Broj brojKa, int trajanjeS) {
        super(vreme, brojOd, brojKa);
        this.trajanjeS = trajanjeS;
    }

    @Override
    public double cena() {
        int cenaUspostavljanjaVeze, cenaZapocetogMinuta;

        if(brojOd.isFiksniTelefon() && brojKa.isFiksniTelefon()) {
            if (!brojOd.istaDrzava(brojKa)) {
                cenaUspostavljanjaVeze = 30;
                cenaZapocetogMinuta = 50;
            }
            else {
                cenaUspostavljanjaVeze = 0;
                cenaZapocetogMinuta = 8;
            }
        }
        else if(!brojOd.isFiksniTelefon() && !brojKa.isFiksniTelefon()){
            cenaUspostavljanjaVeze = 12;
            cenaZapocetogMinuta = 10;
        }
        else {
            cenaUspostavljanjaVeze = 15;
            cenaZapocetogMinuta = 12;
        }

        if(trajanjeS == 0)
            return 0;
        else
            return cenaUspostavljanjaVeze + Math.floor(trajanjeS/60) * cenaZapocetogMinuta;
    }

    @Override
    public String toString() {
        return String.format("%s\t\t %02d:%02d:%02d\t\t%.2f din", super.toString(), trajanjeS/360, (trajanjeS%360)/60, (trajanjeS%60), cena() );
    }
}
