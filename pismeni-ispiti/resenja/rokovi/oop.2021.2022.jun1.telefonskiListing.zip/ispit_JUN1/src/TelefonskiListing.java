import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class TelefonskiListing extends Application {
    private static Map<Broj, List<Usluga>> evidentiraneUsluge = new TreeMap<>();

    public static void main(String[] args) {
        Path pathTelefoni = Paths.get("src/evidentirane_usluge.txt");

        try {
            List<String> linije = Files.readAllLines(pathTelefoni);

            for (String linija : linije){
                String[] elems = linija.split(", ");
                Broj brojOd = new Broj(elems[1]);
                Broj brojKa = new Broj(elems[2]);

                if(!evidentiraneUsluge.containsKey(brojOd))
                    evidentiraneUsluge.put(brojOd, new ArrayList<>());
                if(!evidentiraneUsluge.containsKey(brojKa))
                    evidentiraneUsluge.put(brojKa, new ArrayList<>());

                if(elems.length == 4){
                    Poziv poziv = new Poziv(elems[0], brojOd, brojKa, Integer.parseInt(elems[3]));

                    evidentiraneUsluge.get(brojOd).add(poziv);
                    evidentiraneUsluge.get(brojKa).add(poziv);
                }
                else {
                    Poruka poruka;
                    String[] tekst = Arrays.copyOfRange(elems, 4, elems.length);

                    if(elems[3].equals("0"))
                        poruka = new Poruka(elems[0], brojOd, brojKa, String.join(", ", tekst), false);
                    else
                        poruka = new Poruka(elems[0], brojOd, brojKa, String.join(", ", tekst), true);

                    evidentiraneUsluge.get(brojOd).add(poruka);
                    evidentiraneUsluge.get(brojKa).add(poruka);
                }
            }

        }
        catch (IOException e){
            System.err.println(e.getMessage());
            System.exit(1);
        }

        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxBroj = new HBox(10);
        hBoxBroj.setAlignment(Pos.CENTER);

        TextArea textArea = new TextArea();

        vBoxRoot.getChildren().addAll(hBoxBroj, textArea);

        //---------------------------------------------------------------------

        Label labelBroj = new Label("Broj telefona: ");

        ChoiceBox<String> choiceBox = new ChoiceBox<>();
        for (Broj broj : evidentiraneUsluge.keySet())
            choiceBox.getItems().add(broj.toString());

        Button buttonListing = new Button("Listing");

        hBoxBroj.getChildren().addAll(labelBroj, choiceBox, buttonListing);

        //---------------------------------------------------------------------

        buttonListing.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textArea.clear();

                Broj izabraniBroj = new Broj(choiceBox.getValue().trim());

                List<Usluga> usluge = evidentiraneUsluge.get(izabraniBroj);
                Collections.sort(usluge);

                double ukupnaCena = 0;
                for (Usluga usluga : usluge){
                    textArea.appendText(usluga.toString() + "\n");

                    Broj brojOd = usluga.getBrojOd();
                    if(izabraniBroj.compareTo(brojOd) == 0)
                        ukupnaCena += usluga.cena();
                }
                textArea.appendText("\nUkupna cena: " + ukupnaCena);
            }
        });

        //---------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 700, 250);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Generisanje telefonskog listinga");
        primaryStage.show();
    }
}
