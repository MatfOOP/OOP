import java.util.Arrays;

public class Broj implements Comparable<Broj> {
    private String kodDrzave;
    private String pozivniBroj;
    private String brojTelefona;
    private boolean fiksniTelefon;

    public Broj(String ceoBroj) {
        String[] elems = ceoBroj.substring(1).split(" ");
        kodDrzave = elems[0];
        pozivniBroj = elems[1];
        brojTelefona = elems[2];

        if(pozivniBroj.charAt(0) != '6')
            fiksniTelefon = true;
        else
            fiksniTelefon = false;
    }

    public Broj(Broj b){
        this.kodDrzave = b.kodDrzave;
        this.pozivniBroj = b.pozivniBroj;
        this.brojTelefona = b.brojTelefona;
        this.fiksniTelefon = b.fiksniTelefon;
    }

    public boolean isFiksniTelefon() {
        return fiksniTelefon;
    }

    public boolean istaDrzava(Broj b){
        return this.kodDrzave.equals(b.kodDrzave);
    }

    @Override
    public int compareTo(Broj b) {
        return this.toString().compareTo(b.toString());
    }

    @Override
    public String toString() {
        return "+" + kodDrzave + " " + pozivniBroj + " " + brojTelefona;
    }
}
