import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Vakcinacija extends Application {
    private List<Vakcina> vakcine = new ArrayList<>();
    private List<Grad> gradovi = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxTop = new HBox(10);
        TextArea textAreaDostupneVakcine = new TextArea("");
        HBox hBoxMiddle = new HBox(10);
        TextArea textAreaIzvestaj = new TextArea("");

        vBoxRoot.getChildren().addAll(hBoxTop, textAreaDostupneVakcine, hBoxMiddle, textAreaIzvestaj);

        //-----------------------------------------------------------------------------------------------

        Button buttonUcitaj = new Button("Ucitaj");

        RadioButton radioButtonSoritrano = new RadioButton("sortirano");
        RadioButton radioButtonOriginalno = new RadioButton("originalno");
        ToggleGroup toggleGroup = new ToggleGroup();
        radioButtonSoritrano.setToggleGroup(toggleGroup);
        radioButtonOriginalno.setToggleGroup(toggleGroup);
        radioButtonSoritrano.setSelected(true);

        Button buttonIzvestaj = new Button("Izvestaj");

        hBoxTop.setAlignment(Pos.CENTER);
        hBoxTop.getChildren().addAll(buttonUcitaj, radioButtonSoritrano, radioButtonOriginalno, buttonIzvestaj);

        //-----------------------------------------------------------------------------------------------

        Label labelGrad = new Label("Grad:");
        TextField textFieldGrad = new TextField("");
        Label labelJMBG = new Label("JMBG:");
        TextField textFieldJMBG = new TextField("");
        Button buttonVakcinisi = new Button("Vakcinisi");

        hBoxMiddle.getChildren().addAll(labelGrad, textFieldGrad, labelJMBG, textFieldJMBG, buttonVakcinisi);

        //-----------------------------------------------------------------------------------------------

        buttonUcitaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textAreaDostupneVakcine.clear();

                Path path = Paths.get("src/vakcine.txt");

                try {
                    List<String> linije = Files.readAllLines(path);

                    vakcine = new ArrayList<>();

                    for (String l : linije){
                        String[] strs = l.split(",");

                        if(strs.length == 2){
                            Fajzer fajzer = new Fajzer(strs[0], Jacina.izBroja(Integer.parseInt(strs[1].trim())));
                            vakcine.add(fajzer);
                        }
                        else if(strs.length == 3) {
                            SputnjikV sputnjikV = new SputnjikV(strs[0].trim(), strs[1].trim(), Integer.parseInt(strs[2].trim()));
                            vakcine.add(sputnjikV);
                        }
                        else
                            throw new RuntimeException("Datoteka nije u dobrom formatu.");
                    }

                    if(radioButtonSoritrano.isSelected()){
                        KomparatorVakcina komparator = new KomparatorVakcina();
                        Collections.sort(vakcine, komparator);
                    }

                    for (Vakcina v : vakcine)
                        textAreaDostupneVakcine.appendText(v.toString() + "\n");
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        buttonVakcinisi.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String imeGrada = textFieldGrad.getText();
                String JMBG = textFieldJMBG.getText();

                Grad grad = null;
                for (Grad g : gradovi)
                    if(g.getIme().compareTo(imeGrada) == 0)
                        grad = g;

                if(grad == null) {
                    grad = new Grad(imeGrada);
                    gradovi.add(grad);
                }

                if(vakcine.isEmpty()){
                    textAreaIzvestaj.appendText("Nema vise vakcina!");
                    return;
                }

                Vakcina v = vakcine.remove(0);
                boolean uspehVakcinacije = v.vakcinisi();

                grad.dodajOsobu(JMBG, uspehVakcinacije);

                textAreaIzvestaj.appendText(imeGrada + ": " + JMBG + " je vakcinisan " + v.getIdentifikator() + ".");
                if(uspehVakcinacije)
                    textAreaIzvestaj.appendText(" Vakcinacija je uspesna.\n");
                else
                    textAreaIzvestaj.appendText(" Vakcinacija je neuspesna.\n");
            }
        });

        buttonIzvestaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textAreaIzvestaj.clear();

                for (Grad grad : gradovi)
                    textAreaIzvestaj.appendText(grad.toString());

                textAreaIzvestaj.appendText("\n");
                textAreaIzvestaj.appendText("Ukupno vakcinisanih: " + Vakcina.broj);
            }
        });


        //-----------------------------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 570, 470);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Vakcinacija");
        primaryStage.show();
    }
}