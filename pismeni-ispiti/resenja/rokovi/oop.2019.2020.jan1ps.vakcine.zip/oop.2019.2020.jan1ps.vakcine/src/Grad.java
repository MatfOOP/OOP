import java.util.Map;
import java.util.TreeMap;

public class Grad {
    private String ime;
    private Map<String, Boolean> ljudi;
    private int brojUspesnoVakcinisanih = 0;       //nije receno da se kreira ovaj atribut, ali olaksava kasnije ispis grada

    public Grad(String ime) {
        this.ime = ime;
        this.ljudi = new TreeMap<>();
    }

    public String getIme() {
        return ime;
    }

    public Map<String, Boolean> getLjudi() {
        return ljudi;
    }

    void dodajOsobu(String jmbg, boolean uspeh){
        ljudi.put(jmbg, uspeh);

        if(uspeh)
            brojUspesnoVakcinisanih++;
    }

    @Override
    public String toString() {
        if(brojUspesnoVakcinisanih == 0)
            return "";

        StringBuffer sb = new StringBuffer();
        sb.append(ime + "\n");

        for (Map.Entry<String, Boolean> entry : ljudi.entrySet()){
            String jmbg = entry.getKey();
            Boolean uspeh = entry.getValue();

            if(uspeh)
                sb.append(jmbg + "\n");
        }

        return sb.toString();
    }
}
