import java.util.Random;

public class Fajzer extends Vakcina{
    private Jacina jacinaDoze;

    public Fajzer(String identifikator, Jacina jacinaDoze) {
        super(identifikator);
        this.jacinaDoze = jacinaDoze;
    }

    public Jacina getJacinaDoze() {
        return jacinaDoze;
    }

    @Override
    public boolean vakcinisi() {
        broj++;

        Random random = new Random(java.lang.System.currentTimeMillis());
        int randomInt = random.nextInt(100);

        switch (jacinaDoze){
            case SLABA: return randomInt < 30;
            case SREDNJA: return randomInt < 60;
            case JAKA: return randomInt < 90;
            default: return false;
        }
    }

    @Override
    public String toString() {
        return getIdentifikator() + " " + jacinaDoze.toString();
    }
}
