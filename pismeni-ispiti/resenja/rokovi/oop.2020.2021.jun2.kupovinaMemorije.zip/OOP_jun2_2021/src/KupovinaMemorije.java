import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class KupovinaMemorije extends Application {
    private List<Memorija> memorije = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        Button buttonUcitaj = new Button("Ucitaj");
        TextArea textAreaIspis = new TextArea("");
        HBox hBox1 = new HBox(10);
        HBox hBox2 = new HBox(10);

        vBoxRoot.getChildren().addAll(buttonUcitaj, textAreaIspis, hBox1, hBox2);

        //----------------------------------------------------------------------------

        RadioButton radioButtonHDD = new RadioButton("HDD");
        RadioButton radioButtonSSD = new RadioButton("SSD");
        radioButtonHDD.setSelected(true);
        ToggleGroup toggleGroup = new ToggleGroup();
        radioButtonHDD.setToggleGroup(toggleGroup);
        radioButtonSSD.setToggleGroup(toggleGroup);

        Label labelMemorija = new Label("Memorija:");
        TextField textFieldMemorija = new TextField("");

        hBox1.getChildren().addAll(radioButtonHDD, radioButtonSSD, labelMemorija, textFieldMemorija);

        //----------------------------------------------------------------------------

        Button buttonIzracunaj = new Button("Izracunaj");
        Label labelUkupnaCena = new Label("Ukupna cena:");
        TextField textFieldUkupnaCena = new TextField("");

        hBox2.getChildren().addAll(buttonIzracunaj, labelUkupnaCena, textFieldUkupnaCena);

        //----------------------------------------------------------------------------

        buttonUcitaj.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Path path = Paths.get("src/memorije.txt");

                try{
                    List<String> linije =  Files.readAllLines(path);

                     for (String l : linije){
                         String[] strs = l.split(",");

                         if(strs[0].compareTo("HDD") == 0){
                             String naziv = strs[1].trim();
                             int kolicinaMemorije = Integer.parseInt(strs[2].trim());
                             int brzina = Integer.parseInt(strs[3].trim());
                             Hdd hdd = new Hdd(naziv, kolicinaMemorije, brzina);
                             memorije.add(hdd);
                         }
                         else if(strs[0].compareTo("SSD") == 0){
                             String naziv = strs[1].trim();
                             int kolicinaMemorije = Integer.parseInt(strs[2].trim());
                             SsdTip tip = SsdTip.napraviTip(strs[3].trim());
                             Ssd ssd = new Ssd(naziv, kolicinaMemorije, tip);
                             memorije.add(ssd);
                         }
                     }

                     KomparatorMemorija komparator = new KomparatorMemorija();
                     Collections.sort(memorije, komparator);
                     ispis(memorije, textAreaIspis);
                }
                catch (IOException e){
                    e.printStackTrace();
                }
            }
        });

         buttonIzracunaj.setOnAction(new EventHandler<ActionEvent>() {
             @Override
             public void handle(ActionEvent event) {
                 Integer kolicinaMemorije;
                 String memorija = textFieldMemorija.getText();
                 if(memorija.compareTo("") == 0)
                     kolicinaMemorije = null;
                 else
                     kolicinaMemorije = Integer.parseInt(memorija.trim());

                 List<Memorija> trazeneMemorije = new ArrayList<>();
                 double ukupnaCena = 0.0;

                 if(radioButtonHDD.isSelected()){
                     for (Memorija m : memorije)
                         if(m instanceof Hdd){
                             if(kolicinaMemorije == null || (kolicinaMemorije != null && m.getKolicinaMemorije() >= kolicinaMemorije)) {
                                 trazeneMemorije.add(m);
                                 ukupnaCena += m.cena();
                             }
                         }
                 }
                 else{
                     for (Memorija m : memorije)
                         if(m instanceof Ssd)
                             if(kolicinaMemorije == null || (kolicinaMemorije != null && m.getKolicinaMemorije() >= kolicinaMemorije)) {
                                 trazeneMemorije.add(m);
                                 ukupnaCena += m.cena();
                             }
                 }

                 textAreaIspis.clear();

                 if(trazeneMemorije.size() == 0) {
                     if (radioButtonHDD.isSelected())
                         textAreaIspis.appendText("Nema trazenih HDD memorija");
                     else
                         textAreaIspis.appendText("Nema trazenih SSD memorija");
                 }
                 else
                     ispis(trazeneMemorije, textAreaIspis);

                 textFieldUkupnaCena.setText("" + ukupnaCena);
             }
         });


        //----------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 500, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static <T> void ispis(List<T> lista, TextArea ta){
        ta.clear();

        for (T elem : lista)
            ta.appendText(elem.toString() + "\n");
    }
}
