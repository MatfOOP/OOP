public enum SsdTip {
    FLASH(1), DRAM(2);

    private int rbr;

    SsdTip(int rbr) {
        this.rbr = rbr;
    }

    public int getRbr() {
        return rbr;
    }

    public static SsdTip napraviTip(String s){
        switch (s){
            case "FLASH": return FLASH;
            case "DRAM": return  DRAM;
            default: return FLASH;
        }
    }
}
