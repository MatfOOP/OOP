public class Hdd extends Memorija {
    private int brzina;

    public Hdd(String naziv, int kolicinaMemorije, int brzina) {
        super(naziv, kolicinaMemorije);
        this.brzina = brzina;
    }

    public int getBrzina() {
        return brzina;
    }

    @Override
    public String toString() {
        return "[HDD] " + super.toString() + ", " + brzina + " RPM, " + this.cena();
    }

    @Override
    public double cena() {
        return super.getKolicinaMemorije() * brzina / 1000.0;
    }
}
