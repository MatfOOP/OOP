public abstract class Memorija {
    private String naziv;
    private int kolicinaMemorije;

    public Memorija(String naziv, int kolicinaMemorije) {
        this.naziv = naziv;
        this.kolicinaMemorije = kolicinaMemorije;
    }

    public String getNaziv() {
        return naziv;
    }

    public int getKolicinaMemorije() {
        return kolicinaMemorije;
    }

    @Override
    public String toString() {
        return naziv + " - " + kolicinaMemorije + " GB";
    }

    public abstract double cena();
}
