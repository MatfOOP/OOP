public class Ssd extends Memorija {
    private SsdTip tip;

    public Ssd(String naziv, int kolicinaMemorije, SsdTip tip) {
        super(naziv, kolicinaMemorije);
        this.tip = tip;
    }

    public SsdTip getTip() {
        return tip;
    }

    @Override
    public String toString() {
        return "[SSD] " + super.toString() + ", " + tip + ", " + this.cena();
    }

    @Override
    public double cena() {
        switch (tip){
            case FLASH: return super.getKolicinaMemorije() * 10;
            case DRAM: return super.getKolicinaMemorije() * 20;
            default: return 0;
        }
    }
}
