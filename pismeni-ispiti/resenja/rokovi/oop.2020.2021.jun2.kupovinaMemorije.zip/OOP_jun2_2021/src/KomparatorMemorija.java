import java.util.Comparator;

public class KomparatorMemorija implements Comparator<Memorija> {
    @Override
    public int compare(Memorija m1, Memorija m2) {
        if(m1 instanceof Hdd && m2 instanceof Ssd)
            return +1;
        else if(m1 instanceof Ssd && m2 instanceof Hdd)
            return -1;
        else if(m1.getKolicinaMemorije() != m2.getKolicinaMemorije())
            return -Integer.compare(m1.getKolicinaMemorije(), m2.getKolicinaMemorije());
        else {
            if(m1 instanceof Hdd && m2 instanceof Hdd)
                return Integer.compare(((Hdd) m1).getBrzina(), ((Hdd) m2).getBrzina());
            else
                return Integer.compare(((Ssd) m1).getTip().getRbr(), ((Ssd) m2).getTip().getRbr());
        }
    }
}
