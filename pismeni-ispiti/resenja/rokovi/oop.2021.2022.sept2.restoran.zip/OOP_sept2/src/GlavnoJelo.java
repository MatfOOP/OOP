import java.util.Map;

public class GlavnoJelo extends Jelo {
    public GlavnoJelo(String naziv, Map<Sastojak, Double> spisakSastojaka) throws IllegalArgumentException {
        super(naziv, spisakSastojaka);

        for (Sastojak sastojak : spisakSastojaka.keySet()) {
            if (sastojak.getVrsta() != VrstaSastojka.SLAN && sastojak.getVrsta() != VrstaSastojka.NEUTRALAN)
                throw new IllegalArgumentException("Jelo sadrzi pogresnu vrstu sastojaka");
        }
    }

    @Override
    public double izracunajCenu(boolean popust) {
        if(popust)
            return getOsnovnaCena()*0.9;
        else
            return getOsnovnaCena();
    }
}