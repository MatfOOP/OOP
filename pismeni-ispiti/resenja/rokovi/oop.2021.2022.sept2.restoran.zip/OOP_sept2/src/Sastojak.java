public class Sastojak implements Comparable<Sastojak> {
    private String naziv;
    private VrstaSastojka vrsta;
    private double cenaKG;

    public Sastojak(String naziv, VrstaSastojka vrsta, double cenaKG) {
        this.naziv = naziv;
        this.vrsta = vrsta;
        this.cenaKG = cenaKG;
    }

    public String getNaziv() {
        return naziv;
    }

    public VrstaSastojka getVrsta() {
        return vrsta;
    }

    public double getCenaKG() {
        return cenaKG;
    }

    public double cenaZaKolicinu(double kolicinaG){
        return cenaKG/1000 * kolicinaG;
    }

    @Override
    public int compareTo(Sastojak s) {
        return this.naziv.compareTo(s.naziv);
    }

    @Override
    public String toString() {
        return naziv + " - " + cenaKG + "/kg";
    }
}
