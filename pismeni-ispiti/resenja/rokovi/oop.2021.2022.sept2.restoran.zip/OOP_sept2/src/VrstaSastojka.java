public enum VrstaSastojka {
    SLAN, SLADAK, NEUTRALAN;
}
