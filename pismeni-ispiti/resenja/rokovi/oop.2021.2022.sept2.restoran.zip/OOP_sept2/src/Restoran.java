import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;

public class Restoran extends Application {
    private static Map<String, Sastojak> dostupniSastojci = new TreeMap<>();
    private static List<UredjeniPar<Jelo, Boolean>> jelovnik = new ArrayList<>();

    public static void main(String[] args) {
        Path pathSastojci = Paths.get("src/sastojci.txt");
        try {
            List<String> linije = Files.readAllLines(pathSastojci);

            for (String linija : linije){
                String[] elem = linija.split(" ");
                switch (elem[0]){
                    case "SLAN" : dostupniSastojci.put(elem[1], new Sastojak(elem[1], VrstaSastojka.SLAN, Double.parseDouble(elem[2]))); break;
                    case "SLADAK" : dostupniSastojci.put(elem[1], new Sastojak(elem[1], VrstaSastojka.SLADAK, Double.parseDouble(elem[2]))); break;
                    case "NEUTRALAN" : dostupniSastojci.put(elem[1], new Sastojak(elem[1], VrstaSastojka.NEUTRALAN, Double.parseDouble(elem[2]))); break;
                    default: throw new IllegalArgumentException("Nedozvoljena vrsta sastojka");
                }
            }
        }
        catch (IOException e){
            System.err.println("Nije uspelo otvaranje fajla 'sastojci.txt'");
            System.exit(1);
        }
        catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
            System.exit(1);
        }

        Path pathJelovnik = Paths.get("src/jelovnik.txt");

        try {
            List<String> linije = Files.readAllLines(pathJelovnik);

            for (String linija : linije){
                String[] elem = linija.split(" ");
                String tipJela = elem[0];
                String nazivJela = elem[1];
                Map<Sastojak, Double> spisakSastojaka = new TreeMap<>();
                Boolean dostupnostJela = true;

                for(int i = 2; i < elem.length; i+=2) {
                    String nazivSastojka = elem[i];
                    double kolicinaSastojka = Double.parseDouble(elem[i + 1]);

                    if(dostupniSastojci.keySet().contains(nazivSastojka))
                        spisakSastojaka.put(dostupniSastojci.get(nazivSastojka), kolicinaSastojka);
                    else
                        dostupnostJela = false;
                }

                switch (tipJela){
                    case "P" : jelovnik.add(new UredjeniPar<>(new Predjelo(nazivJela, spisakSastojaka), dostupnostJela)); break;
                    case "G" : jelovnik.add(new UredjeniPar<>(new GlavnoJelo(nazivJela, spisakSastojaka), dostupnostJela)); break;
                    case "D" : jelovnik.add(new UredjeniPar<>(new Dezert(nazivJela, spisakSastojaka), dostupnostJela)); break;
                    default: throw new IllegalArgumentException("Nepoznat tip jela!");
                }
            }
        }
        catch (IOException e){
            System.err.println("Nije uspelo otvaranje fajla 'jelovnik.txt'");
            System.exit(1);
        }
        catch (Exception e){
            System.err.println(e.getMessage());
            System.exit(1);
        }

        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(20);
        vBoxRoot.setPadding(new Insets(20, 10, 10, 10));
        vBoxRoot.setAlignment(Pos.CENTER_RIGHT);

        HBox hBoxJela = new HBox(10);
        VBox vBoxPopusti = new VBox(10);
        Button buttonRacun = new Button("Racun");
        Label labelRacun = new Label("");

        vBoxRoot.getChildren().addAll(hBoxJela, vBoxPopusti, buttonRacun, labelRacun);

        //-------------------------------------------------------------------

        VBox vBoxPredjela = new VBox(10);
        VBox vBoxGlavnaJela = new VBox(10);
        VBox vBoxDeserti = new VBox(10);

        hBoxJela.getChildren().addAll(vBoxPredjela, vBoxGlavnaJela, vBoxDeserti);

        //-------------------------------------------------------------------

        Label labelPredjela = new Label("Predjela:");
        vBoxPredjela.getChildren().add(labelPredjela);

        Label labelGlavnaJela = new Label("Glavna jela:");
        vBoxGlavnaJela.getChildren().add(labelGlavnaJela);

        Label labelDezerti = new Label("Dezerti:");
        vBoxDeserti.getChildren().add(labelDezerti);

        List<UredjeniPar<CheckBox, Jelo>> checkBoxJeloPridruzivanje = new ArrayList<>();

        for (UredjeniPar<Jelo, Boolean> uredjeniPar : jelovnik) {
            Jelo jelo = uredjeniPar.getPrvi();
            Boolean dostupnostJela = uredjeniPar.getDrugi();

            CheckBox checkBox = new CheckBox(jelo.toString());
            if (!dostupnostJela)
                checkBox.setDisable(true);

            if (jelo instanceof Predjelo)
                vBoxPredjela.getChildren().add(checkBox);
            else if (jelo instanceof GlavnoJelo)
                vBoxGlavnaJela.getChildren().add(checkBox);
            else //if (jelo instanceof Dezert)
                vBoxDeserti.getChildren().add(checkBox);

            checkBoxJeloPridruzivanje.add(new UredjeniPar<>(checkBox, jelo));
        }

        //--------------------------------------------------------------------

        ToggleGroup toggleGroup = new ToggleGroup();
        RadioButton radioButtonPopustPredjela = new RadioButton("Popust na predjela 9-12h");
        radioButtonPopustPredjela.setToggleGroup(toggleGroup);
        RadioButton radioButtonPopustGlavnaJela = new RadioButton("Happy hour 17-18h");
        radioButtonPopustGlavnaJela.setToggleGroup(toggleGroup);

        vBoxPopusti.getChildren().addAll(radioButtonPopustPredjela, radioButtonPopustGlavnaJela);

        //-----------------------------------------------------------------------------------------

        buttonRacun.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                double racun = 0;

                for (UredjeniPar<CheckBox, Jelo> uredjeniPar : checkBoxJeloPridruzivanje){
                    CheckBox checkBox = uredjeniPar.getPrvi();
                    Jelo jelo = uredjeniPar.getDrugi();

                    if (checkBox.isSelected()) {
                        if (jelo instanceof Predjelo)
                            racun += jelo.izracunajCenu(radioButtonPopustPredjela.isSelected());
                        else if (jelo instanceof GlavnoJelo)
                            racun += jelo.izracunajCenu(radioButtonPopustGlavnaJela.isSelected());
                        else
                            racun += jelo.izracunajCenu(false);
                    }
             	}

                labelRacun.setTextFill(Color.RED);
                labelRacun.setText("UKUPNO: " + racun + " din");
            }
        });

        //-----------------------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 450, 270);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Jelovnik");
        primaryStage.show();
    }
}
