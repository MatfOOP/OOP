import java.util.Map;

public class Dezert extends Jelo {
    public Dezert(String naziv, Map<Sastojak, Double> spisakSastojaka) throws IllegalArgumentException {
        super(naziv, spisakSastojaka);

        for (Sastojak sastojak : spisakSastojaka.keySet()) {
            if (sastojak.getVrsta() != VrstaSastojka.SLADAK && sastojak.getVrsta() != VrstaSastojka.NEUTRALAN)
                throw new IllegalArgumentException("Jelo sadrzi pogresnu vrstu sastojaka");
        }
    }

    @Override
    public double izracunajCenu(boolean popust) {
        return getOsnovnaCena();
    }
}