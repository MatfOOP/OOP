import java.util.Map;
import java.util.TreeMap;

public abstract class Jelo {
    private String naziv;
    private Map<Sastojak, Double> spisakSastojaka;
    private double osnovnaCena;

    public Jelo(String naziv, Map<Sastojak, Double> spisakSastojaka) {
        this.naziv = naziv;
        this.spisakSastojaka = new TreeMap<>(spisakSastojaka);

        osnovnaCena = 0;
        for (Map.Entry<Sastojak, Double> sastojak : spisakSastojaka.entrySet())
            osnovnaCena += sastojak.getKey().cenaZaKolicinu(sastojak.getValue());
    }

    public double getOsnovnaCena() {
        return osnovnaCena;
    }

    public abstract double izracunajCenu(boolean popust);

    @Override
    public String toString() {
        return naziv + " : " + osnovnaCena;
    }
}