public enum VrstaIgracke {
    MUSKA('M'), ZENSKA('Z'), NEUTRALNA('N');

    private char skracenica;

    VrstaIgracke(char skracenica) {
        this.skracenica = skracenica;
    }

    public char getSkracenica() {
        return skracenica;
    }

    public static VrstaIgracke odSkracenice(char skracenica){
        switch (skracenica){
            case 'M' : return MUSKA;
            case 'Z' : return ZENSKA;
            case 'N' : return NEUTRALNA;
            default: throw new IllegalArgumentException("Nedozvoljena vrednost za vrstu poklona.");
        }
    }
}
