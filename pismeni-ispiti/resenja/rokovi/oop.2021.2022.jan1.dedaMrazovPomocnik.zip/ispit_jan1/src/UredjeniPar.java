public class UredjeniPar<T1, T2> {
    private T1 a;
    private T2 b;

    public UredjeniPar(T1 a, T2 b) {
        this.a = a;
        this.b = b;
    }

    public T1 getPrvi() {
        return a;
    }

    public T2 getDrugi() {
        return b;
    }

    public void setPrvi(T1 a) {
        this.a = a;
    }

    public void setDrugi(T2 b) {
        this.b = b;
    }
}