public class Dete {
    private String imePrezime;
    private PolDeteta pol;

    public Dete(String imePrezime, char pol) {
        this.imePrezime = imePrezime;
        this.pol = PolDeteta.odSkracenice(pol);
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public PolDeteta getPol() {
        return pol;
    }

    @Override
    public String toString() {
        return imePrezime + " (" + pol + ")";
    }
}
