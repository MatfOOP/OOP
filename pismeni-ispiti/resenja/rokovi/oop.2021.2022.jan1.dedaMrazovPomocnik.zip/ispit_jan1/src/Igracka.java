public class Igracka extends Poklon {
    private VrstaIgracke vrstaIgracke;

    public Igracka(String naziv, String ID, int cena, char vrstaIgracke) {
        super(naziv, ID, cena);
        this.vrstaIgracke = VrstaIgracke.odSkracenice(vrstaIgracke);
    }

    public boolean prikladanPoklon(PolDeteta polDeteta){
        if((polDeteta == PolDeteta.MUSKI && this.vrstaIgracke == VrstaIgracke.ZENSKA) ||
           (polDeteta == PolDeteta.ZENSKI && this.vrstaIgracke == VrstaIgracke.MUSKA))
            return false;
        else                                                           
            return true;
    }
}
