import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class DedaMraz extends Application {
    private List<UredjeniPar<Poklon, Integer>> spisakPoklona = new ArrayList<>();;
    private List<Paketic> listaPaketica = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox vBoxRoot = new VBox(10);
        vBoxRoot.setPadding(new Insets(10, 10, 10, 10));

        HBox hBoxGornji = new HBox(10);
        HBox hBoxDonji = new HBox(10);
        hBoxDonji.setAlignment(Pos.CENTER_RIGHT);

        vBoxRoot.getChildren().addAll(hBoxGornji, hBoxDonji);

        //---------------------------------------------------------------------------

        VBox vBoxUnosPodataka = new VBox(10);
        TextArea textArea = new TextArea("");
        textArea.setPrefHeight(300);
        textArea.setPrefWidth(330);

        hBoxGornji.getChildren().addAll(vBoxUnosPodataka, textArea);

        //---------------------------------------------------------------------------

        Button buttonUcitajPoklone = new Button("Ucitaj poklone");
        Button buttonSpisakZaDedaMraza = new Button("Prikazi spisak za Deda Mraza");

        hBoxDonji.getChildren().addAll(buttonUcitajPoklone, buttonSpisakZaDedaMraza);

        //---------------------------------------------------------------------------

        Label labelImePrezime = new Label("Ime i prezime:");
        TextField textFieldImePrezime = new TextField("");

        Label labelPolDeteta = new Label("Pol deteta:");
        RadioButton radioButtonMuski = new RadioButton("Muski");
        RadioButton radioButtonZenski = new RadioButton("Zenski");
        ToggleGroup toggleGroup = new ToggleGroup();
        radioButtonMuski.setToggleGroup(toggleGroup);
        radioButtonZenski.setToggleGroup(toggleGroup);

        Label labelBudzet = new Label("Budzet za paketic:");
        TextField textFieldBudzet = new TextField();

        Button buttonNapuniPaketic = new Button("Napuni paketic");

        vBoxUnosPodataka.getChildren().addAll(labelImePrezime, textFieldImePrezime, labelPolDeteta, radioButtonMuski, radioButtonZenski, labelBudzet, textFieldBudzet, buttonNapuniPaketic);

        //---------------------------------------------------------------------------

        buttonUcitajPoklone.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                buttonUcitajPoklone.setDisable(true);
                try {
                    List<String> linije = Files.readAllLines(Paths.get("src/pokloni.txt"));

                    for(String linija : linije) {
                        String[] elem = linija.split(", ");
                        String IDpoklona = elem[0].trim();
                        String nazivPoklona = elem[1].trim();
                        int cenaPoklona = Integer.parseInt(elem[2].trim());

                        if(IDpoklona.startsWith("I"))
                            spisakPoklona.add(new UredjeniPar<>(new Igracka(nazivPoklona, IDpoklona, cenaPoklona, IDpoklona.charAt(1)), 0));
                        else if(IDpoklona.startsWith("ST"))
                            spisakPoklona.add(new UredjeniPar<>(new Slatkis(nazivPoklona, IDpoklona, cenaPoklona), 0));
                        else if(IDpoklona.startsWith("SN"))
                            spisakPoklona.add(new UredjeniPar<>(new Slanis(nazivPoklona, IDpoklona, cenaPoklona), 0));
                        else
                            throw new IOException("Nepoznat tip poklona!");
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        buttonNapuniPaketic.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    String imePrezime = textFieldImePrezime.getText();
                    int budzet = Integer.parseInt(textFieldBudzet.getText().trim());

                    Dete dete;
                    if (radioButtonMuski.isSelected())
                        dete = new Dete(imePrezime, 'M');
                    else
                        dete = new Dete(imePrezime, 'Z');

                    Paketic paketic = new Paketic(dete, budzet);
                    paketic.napuniPaketic(spisakPoklona);
                    listaPaketica.add(paketic);

                    textArea.setText("Paketic za dete: " + paketic.toString());
                }
                catch (IllegalArgumentException e) {
                    textArea.setText("Neispravno uneti podaci!");
                }
                catch (RuntimeException e){
                    textArea.setText(e.getMessage());
                }
            }
        });

        buttonSpisakZaDedaMraza.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                textArea.setText("");

                for (UredjeniPar<Poklon, Integer> poklon : spisakPoklona)
                    textArea.appendText(poklon.getPrvi().toString() + " - kom " + poklon.getDrugi() + "\n");
            }
        });


        //---------------------------------------------------------------------------

        Scene scene = new Scene(vBoxRoot, 530, 330);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Deda Mrazov pomocnik");
        primaryStage.show();

    }
}
