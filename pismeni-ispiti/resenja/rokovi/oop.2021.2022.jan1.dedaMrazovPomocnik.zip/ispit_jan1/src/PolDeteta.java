public enum PolDeteta {
    MUSKI('M'), ZENSKI('Z');

    private char skracenica;

    private PolDeteta(char skracenica){
        this.skracenica = skracenica;
    }

    public static PolDeteta odSkracenice(char skracenica){
        switch (skracenica){
            case 'M' : return MUSKI;
            case 'Z' : return ZENSKI;
            default: throw new IllegalArgumentException("Nedozvoljena vrednost za pol deteta.");
        }
    }

    @Override
    public String toString() {
        return "" + skracenica;
    }
}
