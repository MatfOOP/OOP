import java.util.*;

public class Paketic {
    private Dete dete;
    private int budzet;
    private List<Poklon> pokloni;

    public Paketic(Dete dete, int budzet) {
        this.dete = dete;
        this.budzet = budzet;
        this.pokloni = new ArrayList<>();
    }

    public void napuniPaketic(List<UredjeniPar<Poklon, Integer>> spisakPoklona) throws RuntimeException {
        Random rand = new Random();

        Collections.sort(spisakPoklona, new Comparator<UredjeniPar<Poklon, Integer>>() {
            @Override
            public int compare(UredjeniPar<Poklon, Integer> up1, UredjeniPar<Poklon, Integer> up2) {
                Poklon p1 = up1.getPrvi();
                Poklon p2 = up2.getPrvi();
                return Integer.compare(p1.getCena(), p2.getCena());
            }
        });

        if (spisakPoklona.isEmpty())
            throw new RuntimeException("Nije ucitan spisak poklona!");

        int minCenaPoklona = spisakPoklona.get(0).getPrvi().getCena();

        while (this.budzet >= minCenaPoklona) {
            UredjeniPar<Poklon, Integer> izabranPoklon = spisakPoklona.get(rand.nextInt(spisakPoklona.size()));
            Poklon poklon = izabranPoklon.getPrvi();
            Integer brojac = izabranPoklon.getDrugi();

            if(poklon.prikladanPoklon(dete.getPol()) && poklon.cena <= this.budzet ){
                this.pokloni.add(izabranPoklon.getPrvi());
                this.budzet -= izabranPoklon.getPrvi().cena;
                izabranPoklon.setDrugi(izabranPoklon.getDrugi() + 1);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(dete.toString() + "\n\n");

        for (Poklon p : pokloni)
            sb.append(p.toString() + "\n");

        return sb.toString();
    }
}
